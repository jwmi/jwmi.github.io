% Using Linear Regression to model motorcycle accident data.
function linear_regression_on_motorcycle

fprintf('\n===========================================\n');

% Which part of the code to run
part = 1.1


% Data preparation ========================================

% Load the dataset into Matlab
all = load('motor.mat');
x = all.Xtrain;
y = all.Ytrain;
x_test = all.Xtest;
y_test = all.Ytest;
x_excluded = 57.6;
y_excluded = 10.7;

% number of data points
n = size(x,1);
n_test = size(x_test,1);

% Rescale x-values to the interval [-1,1]
rescale = @(values) (values-30)/30;
x = rescale(x);
x_test = rescale(x_test);
x_excluded = rescale(x_excluded);

% plot data
figure(1); clf; hold on
plot(x,y,'bo')
plot(x_test,y_test,'ro')
plot(x_excluded,y_excluded,'rx','LineWidth',2,'MarkerSize',12)  % excluded test point



% Polynomial basis functions ===================================================

% polynomial basis functions
polynomials = @(x_i,powers) x_i.^powers;

% form the design matrix using the polynomial basis functions
function A = design_matrix_polynomial(x,powers)
    m_0 = length(powers);
    n_0 = length(x);
    A = zeros(n_0,m_0);
    for i = 1:n_0
        A(i,:) = polynomials(x(i),powers);
    end
end

% Plot the the basis functions
if part==1.1
    m = 19;
    powers = 0:m;
    x_l = linspace(-1,1)';
    % form the design matrix A
    A = design_matrix_polynomial(x_l',powers);
    % plot the columns
    figure(1); clf; hold on
    plot(repmat(x_l,1,m+1),A)
end

% Compute MLEs and plot the prediction function
if part==1.2
    x_l = linspace(-1,1)';
    colors = 'rygbk'; c = 1;
    for m = [0,1,3,5,19]
        powers = 0:m;
        % form the design matrix A
        A = design_matrix_polynomial(x,powers);
        % compute the ML estimate of w (i.e. the least squares estimate)
        w = pinv(A)*y;  % i.e.  w = inv(A'*A)*(A'*y);
        % compute the estimated curve
        A_l = design_matrix_polynomial(x_l',powers);
        plot(x_l,A_l*w,colors(c)); c = c +1;
    end
    axis([-1,1,-150,100])
    legend('train','test','excluded','0','1','3','5','19','Location','EastOutside')
end

% Evaluate the training and test error for MLEs
if part==1.3
    training_error = zeros(1,20);
    test_error = zeros(1,20);
    x_l = linspace(-1,1)';
    for m = 0:19
        powers = 0:m;
        % form the design matrix A
        A = design_matrix_polynomial(x,powers);
        % compute the ML estimate of w (i.e. the least squares estimate)
        w = pinv(A)*y;  % i.e.  w = inv(A'*A)*(A'*y);
        % compute the training error
        training_error(m+1) = sqrt(mean((y-A*w).^2));
        % compute the test error
        A_test = design_matrix_polynomial(x_test,powers);
        test_error(m+1) = sqrt(mean((y_test-A_test*w).^2));
    end
    
    % plot the estimated curves for the best models
    %%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % axis([-1,1,-150,100])
    legend('train','test','excluded','Location','EastOutside')
    
    % Training and test error over the range of models
    training_error
    test_error
    figure(2); clf; hold on
    plot(0:19,training_error,'bo-')
    plot(0:19,test_error,'ro-')
    legend('training error','test error','Location','EastOutside')
end



% Radial basis functions ===================================================

% radial basis functions
RBF = @(x_i,means,sigma) exp(-(x_i-means).^2/(2*sigma^2));

% form the design matrix using the radial basis functions
function A = design_matrix_radial(x,means,sigma)
    m_0 = length(means);
    n_0 = length(x);
    A = zeros(n_0,m_0);
    for i = 1:n_0
        A(i,:) = RBF(x(i),means,sigma);
    end
    A = [ones(n_0,1) A];  % insert a constant column
end

% plot the basis functions
if part==2.1
    figure(2); clf; hold on
    for m = 5:5:15
        means = linspace(-1,1,m)
        sigma = 3*(means(2)-means(1));
        x_l = linspace(-1,1)';
        A_l = design_matrix_radial(x_l',means,sigma);
        subplot(3,1,m/5)
        plot(repmat(x_l,1,m+1),A_l)
    end
end

% Compute MLEs and plot the prediction function
if part==2.2
    x_l = linspace(-1,1)';
    colors = 'rygbk'; c = 1;
    for m = [4,5,10,15,20]
        means = linspace(-1,1,m);
        sigma = 3*(means(2)-means(1));
        % form the design matrix A
        A = design_matrix_radial(x,means,sigma);
        % compute the ML estimate of w (i.e. the least squares estimate)
        w = pinv(A)*y;  % i.e.  w = inv(A'*A)*(A'*y);
        % compute the estimated curve
        A_l = design_matrix_radial(x_l',means,sigma);
        plot(x_l,A_l*w,colors(c)); c = c +1;
    end
    axis([-1,1,-150,100])
    legend('train','test','excluded','4','5','10','15','20','Location','EastOutside')
end




% MAP estimation ===================================================

if part==4
    % hyperparameters
    v_0 = 100;
    v = 400;
    
    
    % polynomial basis =============================
    m = 100;
    powers = 0:m;
    % form the design matrix A
    A = design_matrix_polynomial(x,powers);
    
    % compute the MAP estimate of w (i.e. the regularized least squares estimate)
    I = eye(size(A,2));
    %%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % w = ?
    
    
    % compute the estimated curve
    x_l = linspace(-1,1)';
    A_l = design_matrix_polynomial(x_l',powers);
    plot(x_l,A_l*w)
    
    
    
    % RBF basis =============================
    means = linspace(-1,1,m);
    sigma = 3*(means(2)-means(1));
    % form the design matrix A
    A = design_matrix_radial(x,means,sigma);
    
    % compute the MAP estimate of w (i.e. the regularized least squares estimate)
    I = eye(size(A,2));
    %%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % w = ?
    
    % compute the estimated curve
    x_l = linspace(-1,1)';
    A_l = design_matrix_radial(x_l',means,sigma);
    plot(x_l,A_l*w,'g')
    
    
    legend('train','test','excluded','polynomial','RBF')
end




end










