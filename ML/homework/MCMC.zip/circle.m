function H=circle(center,radius,precision,style)

[x,y,z] = cylinder(radius,precision);
n = size(center,1);
for i = 1:n
    plot(x(1,:)+center(i,1), y(1,:)+center(i,2))
end
