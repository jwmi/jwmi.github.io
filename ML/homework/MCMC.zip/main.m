% Using Markov chain Monte Carlo on the "hard disks in a box" model.
function main
fprintf('\n===========================================\n');

% which part to run
part = 1

% disk size
radius = 1;
diameter = 2*radius;



% reset the random number generator to a standardized value
reset_random = 1;
if reset_random; reset(RandStream.getDefaultStream); end

    
% Functions ===================================================

% Compute the distance between points x and y in the [0,w)x[0,w) torus
function distance = torus_distance(x,y,w)
    direction = 2*(y<w/2)-1;
    distance = min([norm(x-(y+direction.*[0,0]))
                    norm(x-(y+direction.*[w,0]))
                    norm(x-(y+direction.*[0,w]))
                    norm(x-(y+direction.*[w,w]))]);
end

% Given that x is a valid configuration,
% check to see if the configuration obtained by replacing x(m,:) with y is valid
% in the sense that no two disks intersect.
% The point y, as well as all the rows of x, must be in [0,w)x[0,w).
function valid = is_valid(x,y,m,w)
    valid = 1;
    for l = 1:N
        if l==m; continue; end
        if torus_distance(x(l,:),y,w) < diameter
            valid = 0;
            break;
        end
    end
end

% Initialize disk positions as a subset of points in a regular hexagonal grid.
function x = initial_positions(w)
    h_spacing = (radius:diameter:w-radius)';
    v_spacing = (radius:sqrt(3)*radius:w-radius)';
    n_h = length(h_spacing); n_v = length(v_spacing);
    [U,V] = meshgrid(h_spacing,v_spacing);
    U = U + radius*repmat(mod(1:n_v,2)',1,n_h);
    permutation = randperm(n_h*n_v);
    subset = permutation(1:N)';
    x = [U(subset),V(subset)];
end


% Compute the number of "hexagonal crystalline structures"
% i.e. the number of disks with 6 other disks that are 
% separated from it (boundary to boundary) by no more than 1 radius.
function value = f(x,w)
    distances = zeros(N,N);
    for l = 1:N-1
        for j = l+1:N
            distances(j,l) = torus_distance(x(j,:),x(l,:),w);
        end
    end
    distances = distances + distances';
    value = sum(sum(distances < 3*radius) == 7);
end

    
    
    


% Visualizing the torus =================================================

if part==1
    % box width
    w = 15;
    % number of particles to use
    N = 10;
    % initialize disk positions
    x = initial_positions(w);
    
    for i = 1:200
        % Translate all discs in the direction (1,.5)
        s = .1*[1,.5];
        for j = 1:N
            x(j,:) = x(j,:) + s;
        end
        x = mod(x,w);
                
        % Visualize the disks
        figure(1); clf; hold on
        for j = 1:N
            circle_precision = 20;
            y = x(j,:);
            direction = 2*(y<w/2)-1;
            circle(y + direction.*[0,0],radius,circle_precision);
            circle(y + direction.*[w,0],radius,circle_precision);
            circle(y + direction.*[0,w],radius,circle_precision);
            circle(y + direction.*[w,w],radius,circle_precision);
        end
        axis([0,w,0,w])
        axis square
    end
end



% Metropolis =================================================

if part==2
    % box width
    w = 15;
    % number of particles to use
    N = 10;
    % initialize disk positions
    x = initial_positions(w);
    
    % proposal box width, to be used in the proposal distribution
    a = 1;
    
    for i = 1:500
        % Perform a Metropolis iteration
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
        % Visualize the disks
        figure(1); clf; hold on
        for j = 1:N
            circle_precision = 20;
            y = x(j,:);
            direction = 2*(y<w/2)-1;
            circle(y + direction.*[0,0],radius,circle_precision);
            circle(y + direction.*[w,0],radius,circle_precision);
            circle(y + direction.*[0,w],radius,circle_precision);
            circle(y + direction.*[w,w],radius,circle_precision);
        end
        axis([0,w,0,w])
        axis square
    end
end




            
    
% Studying phase transitions =================================================

if part==3
    % Parameters ======================
    
    % number of disks to use
    N = 56;

    % Create the sequence of w values (for the width of the box)
    w_values = [14.15 15 15.5 15.75 16 16.5 17 18 20 25];
    n_w = length(w_values);

    % proposal box widths, one for each value of w
    % (Note: There is not a principled reason behind these choices of a.
    %  I picked these values so that the system would "mix" quickly at each stage.)
    a_values = (w_values-13)/10;

    % number of burn-in iterations in each stage (before sampling)
    burn_in = 10000;
    % number of study-state iterations in each stage (during sampling)
    S = 10000;
    % interval between samples used
    T = 200;


    %  Processing ======================

    % initialize box width
    w = w_values(1);

    % initialize disk positions
    x = initial_positions(w);

    for k = 1:n_w
        % set the new box width
        w = w_values(k);
        a = a_values(k);

        % initialize the accumulated function values
        value = 0;
        count = 0;
        
        for i = 1:burn_in+S
            % Perform a Metropolis iteration
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
            %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            if mod(i,T)==0
                if i>burn_in
                    % accumulate function values
                    value = value + f(x,w);
                    count = count + 1;
                end
                    
                % Visualize the disks
                figure(1); clf; hold on
                circle(x,radius,12);
                axis([0,w,0,w])
                axis square
            end
        end
        
        % compute the MCMC approximation
        approximation(k) = %%%%%%%%%%%%%%%%%%%%%%%  YOUR CODE HERE  %%%%%%%%%%%%%%%%%%%%%
        fprintf('w=%.2f  approx=%.2f\n',w,approximation(k));
        
        % plot the MCMC approximations
        figure(2); clf; hold on
        plot(w_values(1:k),approximation(1:k))
        plot(w_values,zeros(n_w,1),'k')
        
    end
end
    
    
end










