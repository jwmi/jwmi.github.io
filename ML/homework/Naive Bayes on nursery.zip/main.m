% Using Na�ve Bayes (with MLE and Bayesian versions) to classify nursery admission decisions.

fprintf('\n===========================================\n');

% Algorithm parameters
mode = 0;

% reset the random number generator to a standardized value
reset_random = 1;


% Data preparation ========================================

if reset_random; reset(RandStream.getDefaultStream); end

% Load the dataset into Matlab
data = load('nursery.mat');
data = data.data;

% number of data points
n = size(data,1);

% shuffle the data and choose a random subset of size n
data = data(randperm(size(data,1)),:);
data = data(1:n,:);

% number of training and test points
n_train = floor(n/2); % use about half of the points for training
n_test = n-n_train;

% form training and test sets
train = data(1:n_train,:);
test = data(n_train+1:end,:);


if mode==0; fprintf('MLE:\n'); else; fprintf('Bayesian:\n'); end

% Algorithm training ========================================

% train the algorithm
model = naive_bayes_build(train,mode);

% run the algorithm on the training data
[predicted_labels,log_likelihood] = naive_bayes_classify(train,model);

% evaluate performance on the training data
performance = mean(predicted_labels==train(:,end));
fprintf('   train performance = %.4f   log likelihood = %.4f\n\n',performance,log_likelihood);


% Algorithm testing ========================================

% run the algorithm on the test data
[predicted_labels,log_likelihood] = naive_bayes_classify(test,model);

% evaluate performance on the test data
performance = mean(predicted_labels==test(:,end));
fprintf('   test performance  = %.4f   log likelihood = %.4f\n\n',performance,log_likelihood);





