function [predicted_labels,log_likelihood] = naive_bayes_classify(data,model)
% Use a na�ve Bayes classifier to classify test data.
%
% Inputs:
%     data = (n by d+1) (positive integer) matrix of test points,
%            where n = number of data points, and
%                  d = number of dimensions.
%            Each row is a test point.
%            If the true classes are provided in the last column, 
%            this information is used to evaluate the test performance 
%            and compute the log likelihood of the test data under the model.
%     model = na�ve Bayes classifier constructed using naive_bayes_build.m
%
% Outputs:
%     predicted_labels = predicted labels for the data under the model
%     log_likelihood = log likelihood of the data under the model

x = data(:,1:end-1);
y = data(:,end);

% number of points, number of features
[n,d] = size(x);

% Unpack the parameters
n_classes = model.n_classes;
n_values = model.n_values;
class_probability = model.class_probability;
value_probability = model.value_probability;


% Classify the test points
p = zeros(n,n_classes);
for c = 1:n_classes
    % get the probability of each feature value given class c
    conditional = zeros(n,d);
    for i = 1:n
        for j = 1:d
            conditional(i,j) = value_probability(x(i,j),j,c);
        end
    end
    %  the log likelihood of each test data point and class c
    p(:,c) = sum(log(conditional),2) + log(class_probability(c));
end
% predict the class with the highest posterior probability
[max_p,predicted_labels] = max(p,[],2);



% Try to compute the log likelihood of the test data.
if max(y)>0
    % Get the probability of each feature given the class.
    conditional = zeros(n,d);
    prior = zeros(n,1);
    for i = 1:n
        for j = 1:d
            conditional(i,j) = value_probability(x(i,j),j,y(i));
            prior(i) = class_probability(y(i));
        end
    end
    % the log likelihood of each data point and its class
    p = sum(log(conditional),2) + log(prior);
    % the log likelihood of the test data
    log_likelihood = sum(p);

    % Count the number of times each class label occurs
    class_count = hist(y,1:n_classes);
    
    fprintf('     class_probability = [ '); fprintf('%.4f ',class_probability); fprintf(']\n');
    fprintf('     class_count = [ '); fprintf('%d ',class_count); fprintf(']\n');
else
    log_likelihood = NaN;
end










