function model = naive_bayes_build(data,mode)
% Construct a na�ve Bayes classifier.
%
% This implementation requires the values in each dimension to be positive integers,
% and also requires the classes to be positive integers.
%
% Inputs:
%     data = (n by d+1) (positive integer) matrix of training examples,
%            where n = number of data points, and
%                  d = number of dimensions.
%            Each row is a training example, where the last entry is the class.
%     mode = 0 for maximum likelihood estimation (MLE) of the parameters
%            1 for Bayesian na�ve Bayes
%              (with uniform Dirichlet priors are placed on all distributions)
%
% Outputs:
%     model = struct with a na�ve Bayes classifier.

x = data(:,1:end-1);
y = data(:,end);

% number of points, number of features
[n,d] = size(x);
% number of classes
n_classes =  max(y);
% number of possible values for each feature
n_values = max(x);


% Count the number of times each class label occurs
% and estimate the class probabilities.
class_count = hist(y,1:n_classes);
if mode==0  % MLE
    class_probability = class_count/n;
else        % Bayesian
    class_probability = %%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%
end
assert(sum(class_count)==n)


% For each class label, for each feature,
% count the number of times each possible value of the feature occurs,
% and estimate the conditional probability distribution for that feature and class label.
%
% Below, value_probability(v,j,c) = P(X_j = v | Y = c).
% In other words, it is the probability that feature j takes value v given that the class is c.
max_value = max(x(:));
value_count = zeros(max_value,d,n_classes);
value_probability = zeros(max_value,d,n_classes);
for c = 1:n_classes
    if mode==0  % MLE
        if any(y==c)
            value_count(:,:,c) = hist(x(y==c,:),1:max_value);
            value_probability(:,:,c) = value_count(:,:,c)/class_count(c);
        end
    else        % Bayesian
        if any(y==c)
            value_count(:,:,c) = hist(x(y==c,:),1:max_value);
        end
        value_probability(:,:,c) = %%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%
    end
    assert(all(sum(value_count(:,:,c))==class_count(c)))
end


% Store the estimated parameters in a struct
model.n_classes = n_classes;
model.n_values = n_values;
model.class_probability = class_probability;
model.value_probability = value_probability;







