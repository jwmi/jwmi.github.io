% Using Monte Carlo and importance sampling to estimate the area of the Mandelbrot set.
function main
fprintf('\n===========================================\n');

% part to run
part = 1


% reset the random number generator to a standardized value
reset_random = 1;
if reset_random; reset(RandStream.getDefaultStream); end

% The area of the Mandelbrot set has been estimated to be 1.50659177 � 0.00000008
% http://en.wikipedia.org/wiki/Mandelbrot_set#Basic_properties
true = 1.50659177;


% Functions ===================================================

% Grid
function [y,a,b] = grid(w)
    % Choose points in a regular grid
    points = linspace(-2,2,w)';
    [A,B] = meshgrid(points,points);
    a = A(:); b = B(:);
    % evaluate the indicator function of the Mandelbrot set
    y = Mandelbrot(a + i*b);
end

% Monte Carlo
function [y,a,b] = MC(n)
    a = %%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%
    b = %%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%
    y = %%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%
end

% Importance sampling
function [y,a,b,weights] = IS(n)
    % Choose samples from a "mixture of Gaussians" proposal
    
    % probability of each component of the mixture
    pi_1 = 0.85;
    pi_2 = 1-pi_1;
    
    % draw samples from component 1
    mu_1 = [-.1,0];
    C_1 = diag([.1,.2]);
    x_1 = mvnrnd(mu_1,C_1,n);
    
    % draw samples from component 2
    mu_2 = [-1.1,0];
    C_2 = diag([.05,.05]);
    x_2 = mvnrnd(mu_2,C_2,n);

    % choose which component each sample will come from
    I = (rand(n,1)<pi_1);
    a = x_1(:,1).*I + x_2(:,1).*(1-I);
    b = x_1(:,2).*I + x_2(:,2).*(1-I);
    x = [a,b];
    
    % evaluate the indicator function of the Mandelbrot set
    y = Mandelbrot(a + i*b);
    
    % evaluate the probability of the samples, under the uniform distribution on the square
    p = (ones(n,1)/16).*(abs(a)<2).*(abs(b)<2);
    
    % evaluate the probability of the samples, under the proposal distribution
    q_1 = mvnpdf(x,mu_1,C_1);
    q_2 = mvnpdf(x,mu_2,C_2);
    q = pi_1*q_1 + pi_2*q_2;
    
    % compute the "importance weights" of the samples
    weights = p./q;
end
    
    
    
% Processing ===================================================

% Visualize Mandelbrot set
if part==1
    w = 150;  % width of the grid to use
    n = w^2;  % number of points used
    [y,a,b] = grid(w);
    grid_approximation = 16*sum(y)/n
    figure(1); clf; hold on
    plot(a,b,'b.')
    plot(a(y),b(y),'r.')
end



% Approximate area
if part==2
    % The value w determines the width of the grid that is used,
    % and n=w^2 is the number of points used in each method.
    w_values = 10:5:100;
    K = length(w_values);
    
    grid_approximation = zeros(K,1);
    MC_approximation = zeros(K,1);
    IS_approximation = zeros(K,1);

    % grid approximation
    for k = 1:K
        w = w_values(k);
        n = w^2;  % number of points used
    
        % Grid ==================
        [y,a,b] = grid(w);
        grid_approximation(k) = 16*sum(y)/n;
    
        figure(1); clf; hold on
        plot(a,b,'b.')
        plot(a(y),b(y),'r.')
    
        % Monte Carlo =================
        [y,a,b] = MC(n);
        MC_approximation(k) = %%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%
        
        figure(2); clf; hold on
        plot(a,b,'b.')
        plot(a(y),b(y),'r.')
        
        % Importance sampling =================
        [y,a,b,weights] = IS(n);
        IS_approximation(k) = %%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%
    
        figure(3); clf; hold on
        plot(a,b,'b.')
        plot(a(y),b(y),'r.')
        axis([-2,2,-2,2])
        
        % Plot the estimated values and the "true" value
        figure(4); clf; hold on
        plot(w_values.^2,true*ones(K,1),'k-');
        plot(w_values(1:k).^2,grid_approximation(1:k),'r-');
        plot(w_values(1:k).^2,MC_approximation(1:k),'b-');
        plot(w_values(1:k).^2,IS_approximation(1:k),'g-');
        legend('true','grid','MC','IS')
        
    end
end




    
    
    
    
    
end










