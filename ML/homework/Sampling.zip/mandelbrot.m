function Y = Mandelbrot(C)
% Approximately evaluate the indicator function of the Mandelbrot set.
%
% Inputs:
%     C = a matrix or vector of complex values
% Outputs:
%     Y = a matrix or vector of the same size as C, such that each entry is:
%             1 if the corresponding entry of C is estimated to be in the Mandelbrot set, and
%             0 otherwise.

% number of iterations of the map z=z^2+c to evaluate
iterations = 10000;
% value above which sequences are estimated to be unbounded
threshold = 100000;

% initialize
Z = zeros(size(C));
B = zeros(size(C));

for k = 1:iterations
    Z = Z.^2 + C;
    B = max(abs(Z),B);
end

Y = (B<threshold);