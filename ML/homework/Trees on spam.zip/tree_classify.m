function label = tree_classify(point,vertex)
% Use a (binary) classification tree to classify a test point.
% Note: This is a recursive procedure.
%
% Inputs:
%     point = (1 by d) vector.
%     vertex = the root vertex of a tree constructed using tree_build.
% 
% Outputs:
%     label = the predicted label of the point.

if vertex.leaf  % if this vertex is a leaf
    % return the corresponding label
    label = vertex.label;
else
    % otherwise, descend along the appropriate branch
    if point(vertex.j)<=vertex.threshold
        label = tree_classify(point,vertex.left);
    else
        label = tree_classify(point,vertex.right);
    end
end