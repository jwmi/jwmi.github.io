function vertex = tree_build(data,minimum_count)
% Construct a (binary) classification tree for the given training data.
% Note: This is a recursive procedure.
% (Also, this code favors interpretability over efficiency.)
%
% Inputs:
%     data = (n by d+1) matrix of training examples,
%            where n = number of data points, and
%                  d = number of dimensions.
%            Each row is a training example, where the last entry is the class (0 or 1).
%     minimum_count = the smallest number of training examples to allow in each leaf.
% 
% Outputs:
%     vertex = the root vertex of the tree. Each vertex in the tree is a Matlab "struct".

points = data(:,1:end-1);
labels = data(:,end);
[n,d] = size(points);
fprintf('%d ',n);

label_fraction = mean(labels==1);

if (label_fraction==1) || (label_fraction==0) % if all points have same label, make it a leaf    
    % compute the class to predict for this leaf
    vertex.label = (label_fraction>.5);
    vertex.leaf = 1;
    
else  % otherwise look for a split

    % initialize minimization variables
    best_impurity_so_far = Inf;
    best_j_so_far = NaN;
    best_threshold_so_far = NaN;

    for j = 1:d  % for each feature/attribute/dimension
        % sort the data points (in ascending order) according to that feature
        values = sort(points(:,j),'ascend');
        
        for split = 1:n  % for each possible split of the data along that dimension
            threshold = values(split);            
            
            % find the points for which feature j has a value less than or equal to  threshold
            below = (points(:,j)<=threshold);        
            % find the points for which feature j has a value greater than threshold
            above = (points(:,j)>threshold);      
            
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Compute the "impurity" of the split, using the misclassification error.
            
            % YOUR COMPUTATIONS HERE
            
            impurity = % YOUR FORMULA HERE
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            
            % keep the valid split with the smallest impurity
            valid = (minimum_count<min(sum(below),sum(above))); % valid if there are enough points in each side
            if valid && (impurity < best_impurity_so_far)
                best_impurity_so_far = impurity;
                best_j_so_far = j;
                best_threshold_so_far = threshold;
            end
        end    
    end
    % results of the minimization
    j = best_j_so_far;
    threshold = best_threshold_so_far;

    % the attribute j and threshold to use for this vertex
    vertex.j = j;
    vertex.threshold = threshold;

    if ~isnan(j)  % if there are any valid splits
        % recursively compute branches for each side of the best split
        below = (points(:,j)<=threshold);        
        above = (points(:,j)>threshold);
        vertex.left = tree_build(data(below,:),minimum_count);
        vertex.right = tree_build(data(above,:),minimum_count);
        vertex.leaf = 0;
    else
        % if there are not any valid splits, make it a leaf
        
        % compute the class to predict for this leaf
        vertex.label = (label_fraction>.5);  % (if more than half the labels are 1, predict 1)
        vertex.leaf = 1;
    end
end




