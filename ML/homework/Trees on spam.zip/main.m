% Using decision trees to classify spam.

fprintf('\n===========================================\n');

% Number of data points to use
n = 500; % must be less than 4601 for this dataset

% Algorithm parameters
for minimum_count = [n/2,80,40,10:-1:1]%[1:8,50]

% reset the random number generator to a standardized value
reset_random = 1;


% Data preparation ========================================

if reset_random; reset(RandStream.getDefaultStream); end

% Load the dataset into Matlab
data = load('spam_data.txt');

% shuffle the data and choose a random subset of size n
data = data(randperm(size(data,1)),:);
data = data(1:n,:);

% number of data points
n = size(data,1);
n_train = floor(n/2); % use about half of the points for training
n_test = n-n_train;

% form training and test sets
train = data(1:n_train,:);
test = data(n_train+1:end,:);


% Algorithm training ========================================

% build the decision tree
root = tree_build(train,minimum_count);
fprintf('\n')

% run the decision tree on the training data
predicted_labels = zeros(n_train,1);
for i = 1:n_train
    point = train(i,1:end-1);
    predicted_labels(i) = tree_classify(point,root);
end

% evaluate performance on the training data
true_labels = train(:,end);
train_performance = mean(predicted_labels==true_labels);


% Algorithm testing ========================================

% run the decision tree on the test data
predicted_labels = zeros(n_test,1);
for i = 1:n_test
    point = test(i,1:end-1);
    predicted_labels(i) = tree_classify(point,root);
end

% evaluate performance on the test data
true_labels = test(:,end);
test_performance = mean(predicted_labels==true_labels);

fprintf('minimum_count = %d  train_performance = %.4f  test_performance = %.4f\n',minimum_count,train_performance,test_performance);


% Visualize the tree ========================================
if 0
    fprintf('\n ===== Visualize tree =====\n');
    visualize_tree(root);
    
    train_performance
    test_performance
end

end