function visualize_tree(vertex,depth)

if nargin<2
    depth = 0;
end

feature_names = {
'make'
'address'
'all'
'3d'
'our'
'over'
'remove'
'internet'
'order'
'mail'
'receive'
'will'
'people'
'report'
'addresses'
'free'
'business'
'email'
'you'
'credit'
'your'
'font'
'000'
'money'
'hp'
'hpl'
'george'
'650'
'lab'
'labs'
'telnet'
'857'
'data'
'415'
'85'
'technology'
'1999'
'parts'
'pm'
'direct'
'cs'
'meeting'
'original'
'project'
're'
'edu'
'table'
'conference'
';'
'('
'['
'!'
'$'
'#'
'capital_run_length_average'
'capital_run_length_longest'
'capital_run_length_total'
};


if vertex.leaf
    for i = 1:depth; fprintf('  '); end
    if vertex.label==1; fprintf('spam\n'); else; fprintf('not spam\n'); end
else
    for i = 1:depth; fprintf('  '); end
    fprintf([feature_names{vertex.j} ' > %f\n'], vertex.threshold);
    visualize_tree(vertex.right,depth+1);
    for i = 1:depth; fprintf('  '); end
    fprintf([feature_names{vertex.j} ' <= %f\n'], vertex.threshold);
    visualize_tree(vertex.left,depth+1);
end