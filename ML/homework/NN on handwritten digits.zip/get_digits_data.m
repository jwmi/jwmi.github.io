function [train_points,train_labels,test_points,test_labels] = get_digits_data(classes,n_per_class,normalize)


side = 28;  % image size
d = side*side;  % dimension of the train_points
n_classes = length(classes);  % number of classes
n = n_classes*n_per_class;  % number of training train_points to use

% load the dataset into Matlab
data = load('mnist_all.mat');

% extract train and test subsets, put them in a matrix, and put their train_labels in a vector
train_points = zeros(n,d);
train_labels = zeros(n,1);
index = 0;
for i = 1:n_classes
    indices = index+1 : index+n_per_class;
    index = index + n_per_class;
    full = getfield(data,sprintf('train%d',classes(i)));
    
    % choose a random subset of size n_per_class to use for each class
    permutation = randperm(size(full,1));
    subset = permutation(1:n_per_class);
    train_points(indices,:) = full(subset,:);
    train_labels(indices) = classes(i);
end
test_points = [];
test_labels = [];
for label = classes
    full = getfield(data,sprintf('test%d',label));
    test_points = [test_points; full];
    test_labels = [test_labels; label*ones(size(full,1),1)];
end
n_test = length(test_labels);

% utility function to normalize to zero mean and unit norm
function points = normalize_points(points)
    points = double(points);
    points = points-repmat(mean(points,2),1,d);  % zero mean
    for i = 1:size(points,1)
        x = points(i,:)';
        points(i,:) = x'/sqrt(x'*x); % unit norm
    end
end

% convert from integer to double
train_points = double(train_points);
test_points = double(test_points);

if normalize
    % normalize to zero mean and unit norm
    train_points = normalize_points(train_points);
    test_points = normalize_points(test_points);
end

end



