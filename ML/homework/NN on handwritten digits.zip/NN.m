function label = NN(x,points,labels)
% Return the 1-nearest neighbor classification of x for the given data.
% Inputs:
%     x = (1 by d) point to be classified.
%     points = (n by d) matrix of example data points. Each row is a point.
%     labels = (n by 1) vector of labels for the corresponding data points.
% Output:
%     label = predicted label for x.

[n,d] = size(points);

% YOUR CODE HERE
% YOUR CODE HERE
% YOUR CODE HERE
% YOUR CODE HERE
% YOUR CODE HERE
% YOUR CODE HERE
% YOUR CODE HERE
% YOUR CODE HERE
% YOUR CODE HERE
% YOUR CODE HERE
% YOUR CODE HERE
% YOUR CODE HERE

% the label of the nearest point
label = % YOUR CODE HERE
