% Using k-Nearest Neighbor (with k = 1) to classify handwritten digits.

fprintf('\n===========================================\n');

for n_per_class = [1,10,50,100,200]  % the number of points to use per class

fprintf('\n n_per_class = %d   ',n_per_class);

classes = [1,2,7];  % which digit classes to use

% Algorithm parameters
normalize = 1;

% reset the random number generator to a standardized value
reset_random = 1;


% Data preparation ========================================

if reset_random; reset(RandStream.getDefaultStream); end

% extract train and test subsets
[train_points,train_labels,test_points,test_labels] = get_digits_data(classes,n_per_class,normalize);

n_test = length(test_labels); % number of test points



% Algorithm training ========================================

% (none)


% Algorithm testing ========================================

% run the classifier on the test data
predicted_labels = zeros(n_test,1);
for i = 1:n_test
    x = test_points(i,:);
    predicted_labels(i) = NN(x,train_points,train_labels);
end

% evaluate performance on the test data
test_performance = mean(predicted_labels==test_labels);

fprintf('test_performance = %.4f    ',test_performance);



% Visualization ========================================

matches = (predicted_labels==test_labels); % which test points were correctly classified

% utility function to convert vectors to images
side = 28;
unflatten = @(x) fliplr(imrotate(reshape(x,side,side),-90));

% Display 5 random examples of matches, and 5 random examples of mismatches
figure(1); clf;
colormap gray
for i = 1:5
    while 1, index = randi(n_test); if matches(index), break; end; end
    subplot(2,5,i);
    imagesc(unflatten(test_points(index,:)));
    title(sprintf('true=%d  predicted=%d',test_labels(index),predicted_labels(index)));
end
for i = 1:5
    while 1, index = randi(n_test); if 1-matches(index), break; end; end
    subplot(2,5,i+5);
    imagesc(unflatten(test_points(index,:)));
    title(sprintf('true=%d  predicted=%d',test_labels(index),predicted_labels(index)));
end
% fprintf('(hit enter to continue)'); pause




end


fprintf('\n');






