function means = EM_GMM(x,k)
% Cluster of the data in x using EM on a Gaussian mixture model (GMM)
%
% Inputs:
%   x = (n x d) matrix of n data points in R^d
%   k = number of mixture components to use
%

% size of the data set
[n,d] = size(x);

% terminate the algorithm when every data point is
% within tolerable_change of its previous position
tolerable_change = 0.001;

% Initialize mixing components
a = ones(k,1)/k;

% Initialize means by randomly choosing k points from x
indices = randperm(n);
means = x(indices(1:k),:);
means_old = means;

% Initialize covariance matrices
C = repmat(eye(d),[1,1,k]);

% Initialize the probability and responsibility matrices
P = zeros(n,k);
r = zeros(n,k);

change = Inf;
while change>tolerable_change
    
    % compute the probabilities
    for i = 1:k
        P(:,i) = mvnpdf(x,means(i,:),C(:,:,i));
    end
    totals = P*a;
    
    % compute the responsibilities
    for i = 1:k
        r(:,i) = a(i)*P(:,i)./totals;
    end
    
    % compute the expected counts
    N = sum(r)';
    
    % Update the mixing components
    a = N/n;
    
    % Update the means
    for i = 1:k
        means(i,:) = r(:,i)'*x / N(i);
    end
    
    % Update the covariance matrices
    for i = 1:k
        C(:,:,i) = 0;
        for j = 1:n
            C(:,:,i) = C(:,:,i) + r(j,i)*x(j,:)'*x(j,:);
        end
        C(:,:,i) = C(:,:,i)/N(i) - means(i,:)'*means(i,:);
        C(:,:,i) = (C(:,:,i) + C(:,:,i)')/2;  % enforce symmetry  --- roundoff error may break it
    end
    
    
    
    % largest distance between previous positions and new positions
    change = max(sqrt(sum((means-means_old).^2, 2)));
    means_old = means;
    
    % plot status
    [~,most_probable] = max(r,[],2);
    figure(2); clf; hold on
    colors = 'rgb';
    for i = 1:k
        plot(means(i,1),means(i,2),[colors(i) 'o'],'MarkerSize',15,'LineWidth',3);
        plot(x(most_probable==i,1),x(most_probable==i,2),[colors(i) '.']);
    end
    % pause(.5)
    

end

% plot the responsibilities
if 0
    for i = 1:n
        if k==2; color = [r(i,1) r(i,2) 0];
        else; color = r(i,:); end
        plot(x(i,1),x(i,2),'.','MarkerEdgeColor',color);
    end
end










