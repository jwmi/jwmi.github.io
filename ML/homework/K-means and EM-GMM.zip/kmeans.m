function centers = kmeans(x,k)
% Cluster the data in x using K-means, with k centers.
%
% Inputs:
%   x = (n x d) matrix of n data points in R^d
%   k = number of centers to use
% Outputs:
%   centers = (k x d) matrix of k points in R^d, the centers of the clusters

% size of the data set
[n,d] = size(x);

% Initialize centers by randomly choosing k points from x.
permutation = randperm(n);  % this generates a random ordering of the numbers 1,...,n
centers = x(permutation(1:k),:);

while 1
    old_centers = centers;
    
    % Compute the distance from each center to each point in x.
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Find the center which is nearest to each point.
    
    % Your code should create a (n by 1) vector called "nearest" such that
    % nearest(i)==j where centers(j,:) is the row with the smallest distance from x(i,:).
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    % Update the centers.
    
    % Set centers(j,:) to the average of the points x(i,:) such that nearest(i)==j.
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    
    % check for termination
    if all(centers(:)==old_centers(:)); break; end
    
    % plot
    figure(1); clf; hold on
    color = 'rgb';
    for j = 1:k
        plot(centers(j,1),centers(j,2),[color(j) 'o'],'MarkerSize',15,'LineWidth',3);
        plot(x(nearest==j,1),x(nearest==j,2),[color(j) '.']);
    end
    % (I put this "pause" here so you can see the evolution of the algorithm.
    % Otherwise it is too fast to see.)
    pause(.5)    

end














