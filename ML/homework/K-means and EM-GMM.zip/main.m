% Using K-means and EM-GMM to cluster the Old Faithful data set.
function main

fprintf('\n===========================================\n');

% part to run
part = 1

% reset the random number generator to a standardized value
reset_random = 0;


% Data preparation ========================================

if reset_random; reset(RandStream.getDefaultStream); end

% load the data set into Matlab
x = load('faithful.txt');
% number of data points
n = size(x,1);



% Process the data set ===================================================

% Cluster the original data set with K-means only
if part==1
    k = 2;
    % cluster using K-means
    centers = kmeans(x,k);
end

% Cluster the original data set with both algorithms
if part==2
    k = 2;
    % cluster using K-means
    centers = kmeans(x,k);
    % cluster using EM on a GMM
    centers = EM_GMM(x,k);
end

% Cluster the data set along with some extra points
if part==3

    % add some extra points to the data set
    n_extra = 150;
    mu = [4,80];
    C = diag([1,5]);
    extra = mvnrnd(mu,C,n_extra);
    x = [x; extra];


    k = 3;
    % cluster using K-means
    centers = kmeans(x,k);
    % cluster using EM on a GMM
    centers = EM_GMM(x,k);
end
    

end










