% Performing model selection on Bayesian linear regression applied to a synthetic data set.
function model_selection

fprintf('\n===========================================\n');

% number of data points
n = 20;
n_test = 60;

% Number of folds for cross-validation
K = 10

% Which basis to use (1:polynomial, 2:RBF)
basis = 1
% number of basis functions to use (except for the constant function)
m = 100;
% precision (1/variance) of Y_i given w 
a = 1;
% prior precision (1/variance)
b = 0.1;
    
    
% range of b values to use for model selection
b_values = logspace(-8,2,100);

% reset the random number generator to a standardized value
reset_random = 1;


% Data preparation ========================================

if reset_random; reset(RandStream.getDefaultStream); end

% true function
f = @(x) 20*x.^4 + 10*x - 5;


% generate data set
x = rand(n,1)*2-1;  % uniformly choose points x from [-1,1]
y = randn(n,1)/sqrt(a) + f(x); % distribute points y normally about the true function f(x)
x_test = rand(n,1)*2-1;
y_test = randn(n,1)/sqrt(a) + f(x_test);

% plot data
figure(1); clf; hold on
x_plot = linspace(-1,1,200)';
plot(x_plot,f(x_plot),'b:')
plot(x,y,'bo')
plot(x_test,y_test,'ro')




% Polynomial basis functions ===================================================

% polynomial basis functions
polynomials = @(x_i,powers) x_i.^powers;

% form the design matrix using the polynomial basis functions
function A = design_matrix_polynomial(x,powers)
    m_0 = length(powers);
    n_0 = length(x);
    A = zeros(n_0,m_0);
    for i_ = 1:n_0
        A(i_,:) = polynomials(x(i_),powers);
    end
end

% Radial basis functions ===================================================

% radial basis functions
RBF = @(x_i,means,sigma) exp(-(x_i-means).^2/(2*sigma^2));

% form the design matrix using the radial basis functions
function A = design_matrix_radial(x,means,sigma)
    m_0 = length(means);
    n_0 = length(x);
    A = zeros(n_0,m_0);
    for i_ = 1:n_0
        A(i_,:) = RBF(x(i_),means,sigma);
    end
    A = [ones(n_0,1) A];  % insert a constant column
end



% Computing the posterior distribution ===================================================

% x points for plotting
x_plot = linspace(-1,1,200)';

if basis==1
    % polynomial basis
    powers = 0:m;
    % form the design matrix A
    A = design_matrix_polynomial(x,powers);
    A_test = design_matrix_polynomial(x_test,powers);
    A_plot = design_matrix_polynomial(x_plot,powers);
else
    % RBF basis
    means = linspace(-1,1,m);
    sigma = 3*(means(2)-means(1));
    % form the design matrix A
    A = design_matrix_radial(x,means,sigma);
    A_test = design_matrix_radial(x_test,means,sigma);
    A_plot = design_matrix_radial(x_plot,means,sigma);
end

% compute the posterior distribution of w (given the data)

% posterior covariance
I = eye(size(A,2));
C = %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% posterior mean
mu = %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% mean of Y (for each point in x_plot) given the data 
u = %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% the variance of Y (for each point in x_plot) given the data
variance = %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% plot the mean prediction function f(x) given the data
plot(x_plot',u,'k')
% Plot 2x error bars (+/- 2*standard deviation) for Y given the data
standard_deviation = sqrt(variance);
plot(x_plot',u+2*standard_deviation,'g') 
plot(x_plot',u-2*standard_deviation,'g') 

axis([-1,1,-12,30])



% Model selection ===================================================


% Shuffle the data for cross-validation
permutation = randperm(n);
x_shuffled = x(permutation);
y_shuffled = y(permutation);
% fold size for cross-validation
fold_size = n/K;  % note: things work out nicely in this case since this is an integer for K = 5 and 10

n_values = length(b_values);
L = zeros(n_values,1);
CV = zeros(n_values,K);
test_error = zeros(n_values,1);
for i = 1:n_values
    b = b_values(i);
    
    % posterior covariance
    I = eye(size(A,2));
    C = %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % posterior mean
    mu = %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % compute the marginal log-likelihood
    L(i) = (1/2)*((m+1)*log(b) + n*log(a/(2*pi)) + sum(log(eig(C))) - b*(mu'*mu) - a*sum((y-A*mu).^2));
    
    
    % compute the actual test error
    test_error(i) = sqrt(mean((y_test-A_test*mu).^2));
    
    
    % compute the cross-validation estimate of the error
    for k = 1:K
        % indices to be used for validation
        validation = %%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%
        % indices to be used for training
        training = %%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%
        
        % subset of x_shuffled to be used for validation
        x_validation = %%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%
        % subset of y_shuffled to be used for validation
        y_validation = %%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%
        % subset of x_shuffled to be used for training
        x_train = %%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%
        % subset of y_shuffled to be used for training
        y_train = %%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%
        
        % compute the design matrices
        if basis==1
            % polynomial basis
            powers = 0:m;
            A_train = design_matrix_polynomial(x_train,powers);
            A_validation = design_matrix_polynomial(x_validation,powers);
        else
            % RBF basis
            means = linspace(-1,1,m);
            sigma = 3*(means(2)-means(1));
            A_train = design_matrix_radial(x_train,means,sigma);
            A_validation = design_matrix_radial(x_validation,means,sigma);
        end
    
        I = eye(size(A_train,2));
        
        % posterior covariance (given the subset of examples x_train,y_train)
        C = %%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%
        
        % posterior mean (given the subset of examples x_train,y_train)
        mu = %%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%
        
        % compute the estimated test error for the k'th round, for the i'th value of b
        CV(i,k) = sqrt(mean((y_validation-A_validation*mu).^2));
        
    end
end

% compute the CV estimate for each value of b
CV_estimate = mean(CV,2);

% plot the marginal log-likelihood
figure(2); clf; hold on
plot(log10(b_values),L,'b.')
title('marginal log-likelihood')

% plot the actual test error and the cross-validation estimate
figure(3); clf; hold on
plot(log10(b_values),log10(test_error),'r.')
plot(log10(b_values),log10(CV_estimate),'g.')
title('actual test error, and cross-validation')
legend('actual','CV')

% values maximizing/minimizing each quantity
fprintf('\nOptimal values of b under each quantity:\n');
[value,index] = min(test_error);
fprintf('    b = %.4f minimizes actual test error\n',b_values(index));
[value,index] = min(CV_estimate);
fprintf('    b = %.4f minimizes cross-validation estimated error\n',b_values(index));
[value,index] = max(L);
fprintf('    b = %.4f maximizes marginal log-likelihood\n',b_values(index));

    




end










