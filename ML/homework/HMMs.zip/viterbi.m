function [z,prob] = viterbi(x, T, E, p)
% Return the MAP path for a sequence of HMM observations
%
% Inputs:
%  x (1xn) observations at times t=1:n (each an integer from 1..m)
%  T (kxk) transition probability matrix - T(i,j) is P of going from i to j
%  E (fun) emission probabilities - E(x,j) is P of seeing output x in state j
%  p (1xk) starting probability for each state
%   where
%  n = # of observations
%  k = # of states
%  m = # of elements in observation space
%
% Outputs:
%  z (1xn) MAP path (times t=1:n) (most probable sequence of hidden states)
%  prob (1x1) probability of MAP path


k = length(p);   % # of states
n = length(x);   % # of observations
R = zeros(n,k);  % paths (routes), represented as backwards linked lists
% R(t,j) is the (t-1)th state in the Viterbi path ending at state j at step t
% (R(0,j) is not used.)

% Convert to log-probabilities
p = log(p);
T = log(T);
%E = log(E);

% Initialize
p = p + log(E(x(1),1:k));

% Compute the maximal path
for t=2:n  % each observation
    % Now, p(j) is the probability for the V-path ending at state j at step t-1
    M = repmat(p', 1,k); % matrix of state metrics
    P = M + T;           % compute probabilities
    [p,inds] = max(P);   % max value and corresponding index
                         %   for each column (each next state)
    p = p + log(E(x(t),1:k)); % mult by probabilities of seeing x(t) (each state j)
    R(t,:) = inds;       % append pointers to previous nodes in V-paths
end

% Reconstruct the maximal path from R, walking back from the end of the max path
[log_prob,j] = max(p);
z = zeros(1,n);
for t=n:-1:1
    z(t) = j;
    j = R(t,j);
end

% Convert back to probability
prob = exp(log_prob);


