% Using the Viterbi algorithm on an HMM applied to a synthetic data set.
function HMMs

fprintf('\n===========================================\n');

% number of data points
n = 1000;


% reset the random number generator to a standardized value
reset_random = 1;


% Data preparation ========================================

if reset_random; reset(RandStream.getDefaultStream); end

% transition matrix
p_switch = .01; % probability of switching from state 1 to state 2
T = [1-p_switch   p_switch
       p_switch 1-p_switch];

% emission distributions
means = [-2,2]; % the mean of the emission distribution for each hidden state
sigma = [6,6]; % the standard deviation ...
% This function takes a single observed value x and a vector of hidden states z,
% and returns the value of the normal PDF evaluated at x for 
% each mean and standard deviation specified by the hidden states.
emission_distribution = @(x,z) normpdf(x,means(z),sigma(z));

% Initial distribution for the hidden state
initial_distribution = [.5,.5];



% Generate the data set ===================================================

%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sequence of n hidden states
z = %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sequence of n observed values
x = %%%%%%%%%%%%%%%%%%%%%%%%%%%% YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%




% Visualize the data set ===================================================

% plot the observations x
figure(1); clf; hold on
plot(x,'g.')



% ===================================================
% Compute the Viterbi path (i.e. most probable sequence of hidden states, given x) 
enabled = 0;

if enabled
    [z_MAP,probability] = viterbi(x, T, emission_distribution, initial_distribution);

    % plot data and results
    figure(2); clf; hold on
    plot(x,'g.')
    plot(means(z),'r')
    plot(means(z_MAP),'b')
    legend('observed','hidden','Viterbi')
end







    




end










