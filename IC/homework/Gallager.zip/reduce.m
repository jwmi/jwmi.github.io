function A = reduce(A)

[m,n] = size(A);

for i = 1:m
    % eliminate entries above (i,i)
    for k = 1:i-1
        if A(k,i)==1
            A(k,:) = mod(A(k,:) + A(i,:),2);
        end
    end
end

