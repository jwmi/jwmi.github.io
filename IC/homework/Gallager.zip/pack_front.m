function [A,B] = pack_front(A,B)

[m,n] = size(A);

for i = 1:m
    % swap columns so that A(i,i)==1
    swap = find(A(i,i:end),1);
    assert(~isempty(swap))
    
    A(:,[i,swap+i-1]) = A(:,[swap+i-1,i]);
    B(:,[i,swap+i-1]) = B(:,[swap+i-1,i]);
end






