function [H,G] = construct_gallager(c,d,m,visualize)
% Return a parity check matrix H and generator matrix G for a Gallager code with parameters c,d,m.
%
% Inputs:
%     c = number of ones per column
%     d = number of ones per row
%     m = number of rows in the parity check matrix (must be a multiple of c)
%     visualize = 1 to display images of H and G,
%                 0 to not display (default)
% 
% Outputs:
%     H = m-by-n parity check matrix (where n = d*(m/c))
%     G = k-by-n generator matrix (where k = n-m)


steps = 1e5; % number of MCMC steps to use when generating H
             % (in practice, this should depend on how big the matrix is)

if nargin<4; visualize = 0; end
             
assert(mod(m,c)==0)
             
n = d*(m/c); % number of columns (codeword length)
k = n-m; % number of source bits

% construct the parity check matrix H
H = zeros(m,n);
for b = 1:(m/c) % initialize H
    for i = 1:c
        i_ = (b-1)*c + i;
        for j = 1:d
            j_ = (b-1)*d + j;
            H(i_,j_) = 1;
        end
    end
end
fprintf('sampling a random parity check matrix...\n')
H = binary_matrix_MCMC(H,steps); % randomly sample H using MCMC
assert(all(sum(H,1)==c))
assert(all(sum(H,2)==d))


% Construct the generator matrix G
fprintf('constructing the generator matrix...\n')
R = row_echelon(H); % Convert H to row echelon form by Gaussian elimination mod 2

[R,H] = pack_front(R,H); % permute to ensure that the left-hand m by m submatrix is full rank

R = reduce(R); % reduced row echelon form mod 2

% swap left and right-hand sides
R = circshift(R,[0,k]);
H = circshift(H,[0,k]);

F = R(:,1:k); % H = A*[F I] for some matrix A
G = [eye(k) F']; % generator matrix

% verify that the generator matrix is correct
verify = mod(H*G',2);
assert(all(verify(:)==0))

% visualize H and G
if visualize
    figure(1); clf; colormap gray
    imagesc(1-H)
    figure(2); clf; colormap gray
    imagesc(1-G)
end

% H
% F
% G






