function x = binary_matrix_MCMC(x,steps)

[m,n] = size(x);
c = sum(x(:,1)); % column sums
i = [0,0];
j = [0,0];

% generate random indices to determine which entries to swap
random_n = randi(n,steps,2);
random_c = randi(c,steps,2);

for step = 1:steps
    j(1) = random_n(step,1);
    j(2) = random_n(step,2);
    for u = [1,2]
        index = random_c(step,u);
        i_list = find(x(:,j(u)));
        i(u) = i_list(index);
    end
    
    % if |1 0| then swap to |0 1|
    %    |0 1|              |1 0|
    if x(i(1),j(2))==0 && x(i(2),j(1))==0
        x(i(1),j(1)) = 0;
        x(i(2),j(2)) = 0;
        x(i(1),j(2)) = 1;
        x(i(2),j(1)) = 1;
    end
end
