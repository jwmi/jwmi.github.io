function A = row_echelon(A)

[m,n] = size(A);

i = 1;
j = 1;
while j<=n
    % swap rows so that A(i,j)==1
    swap = find(A(i:end,j),1);
    if isempty(swap)
        j = j + 1;
        continue
    end
    A([i,swap+i-1],:) = A([swap+i-1,i],:);
    % eliminate entries below (i,j)
    for k = i+1:m
        if A(k,j)==1
            A(k,:) = mod(A(k,:) + A(i,:),2);
        end
    end
    
    i = i + 1;
    j = j + 1;
end



