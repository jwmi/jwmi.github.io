function y = logsum(x)
% Return log(sum(exp(x))) in a way that avoids numerical issues arising from values with large magnitude.
% Inputs:
%  x = (n-by-1) vector

m = max(x);
if m==-inf
    y = -inf;
else
    y = log(sum(exp(x-m)))+m;
end

