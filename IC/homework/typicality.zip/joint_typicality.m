% Joint typicality - empirical validation

fprintf('================================================\n');

entropy = @(p) -p(:)'*log2(p(:));

figure(1); clf; hold on
s = 1; % subplot counter

for n = [1e3,1e4,1e5,1e6,1e7]
    fprintf('=========  n=%g  ==========\n',n)
    a = .3; % P(X = 1)
    f = .25; % P(Y = 1-x | X = x)
    b = a*(1-f) + (1-a)*f; % P(Y = 1)
    m = 1e4; % number of sequences to use
    epsilon = .001;
    
    % sampling (approximate)
    k_x = randn(m,1) * sqrt(n*a*(1-a)) + n*a; % Gaussian approximation
    k_f = randn(m,1) * sqrt(n*f*(1-f)) + n*f; % Gaussian approximation
    c = ((n-k_x)/n).*(k_f/n) + (k_x/n).*((n-k_f)/n);
    k_y = randn(m,1) .* sqrt(n*c.*(1-c)) + n*c; % independence approximation and Gaussian approximation
    
    max_counts = max(max(hist(k_x,25)),max(hist(k_y,25)));

    % typical x
    H_X = entropy([a,1-a]);
    lower_bound = ((H_X-epsilon)+log2(1-a))/((1/n)*log2((1-a)/a));
    upper_bound = ((H_X+epsilon)+log2(1-a))/((1/n)*log2((1-a)/a));
    typical_x = (k_x >= lower_bound)&(k_x <= upper_bound);
    subplot(5,3,s); s = s+1;
    hist(k_x,25);
    line([lower_bound,lower_bound],[0,max_counts],'Color','y','LineWidth',4)
    line([upper_bound,upper_bound],[0,max_counts],'Color','r','LineWidth',4)
    
    % typical y
    H_Y = entropy([b,1-b]);
    lower_bound = ((H_Y-epsilon)+log2(1-b))/((1/n)*log2((1-b)/b));
    upper_bound = ((H_Y+epsilon)+log2(1-b))/((1/n)*log2((1-b)/b));
    typical_y = (k_y >= lower_bound)&(k_y <= upper_bound);
    subplot(5,3,s); s = s+1;
    hist(k_y,25);
    line([lower_bound,lower_bound],[0,max_counts],'Color','y','LineWidth',4)
    line([upper_bound,upper_bound],[0,max_counts],'Color','r','LineWidth',4)
    
    % typical pairs
    p_joint = [a,1-a]'*[f,1-f];
    H_XY = entropy(p_joint);
    values = (1/n)*(k_x*log2(1/a)+(n-k_x)*log2(1/(1-a)) ...
                   +k_f*log2(1/f)+(n-k_f)*log2(1/(1-f)));
    typical_pairs = (abs(H_XY - values)<=epsilon);
    subplot(5,3,s); s = s+1;
    hist(values,25);
    line([H_XY-epsilon,H_XY-epsilon],[0,max_counts],'Color','y','LineWidth',4)
    line([H_XY+epsilon,H_XY+epsilon],[0,max_counts],'Color','r','LineWidth',4)

    % approximate probability of the jointly typical set
    jointly_typical = typical_x & typical_y & typical_pairs;
    p_typical = (1/m)*sum(jointly_typical);
    fprintf('P(jointly typical) = %f\n',p_typical)
    
    % approximate probability of independent sequences being jointly typical
    % (using importance sampling)
    log_importance_weights = k_y*log(b)+(n-k_y)*log(1-b) - k_f*log(f)-(n-k_f)*log(1-f);
    log_p_independent = log(1/m)+logsum(log_importance_weights(jointly_typical));
    fprintf('log P(indep seqs are jointly typical) = %g\n',log_p_independent)
    
    % compare with mutual information
    I_XY = H_X + H_Y - H_XY;
    fprintf('(1/n)log2(1/P)=%f   I(X:Y)=%f\n',-(1/n)*log_p_independent/log(2),I_XY);
        
end
















