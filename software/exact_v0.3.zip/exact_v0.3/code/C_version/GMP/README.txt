
This folder contains the GMP headers and library files for WINDOWS.

=====================================

The code uses the Gnu Multiple Precision (GMP) library (http://gmplib.org) for handling integers of arbitrary size. I've included a precompiled copy of the GMP 4.1 libraries for Windows, downloaded from  http://www.cs.nyu.edu/exact/core/gmp/.
GMP is distributed under the LGPL license.



