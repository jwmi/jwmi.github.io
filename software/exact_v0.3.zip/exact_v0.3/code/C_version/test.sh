#!/bin/bash

# Example of how to run count and sample.

# For the meaning of the input arguments, 
# you can simply run count or sample without arguments.

./count.exe input.dat table.bin 0
./sample.exe input.dat table.bin output.dat 10 0

# You can look at output.dat to see the samples that were drawn.


