FlowCAP-I GvHD datasets

This copy of the data was obtained from https://github.com/hl475/deepcytof
(Repository for the paper "Gating mass cytometry data by deep learning" by Li, Shaham, Stanton, Yao, Montgomery, and Kluger, Bioinformatics, 2017.)

This is extracted from the full FlowCAP-I repository, which is available from:
http://flowcap.flowsite.org/Availability.html
http://flowcap.flowsite.org/codeanddata/FlowCAP-I.zip

Note that the label is 0 when no manual labeling provided for that cell.  The Li et al (2017) labels are permuted in some cases compared to the original, but this does not affect the results.
