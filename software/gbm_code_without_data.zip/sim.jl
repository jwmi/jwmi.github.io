# Simulations to assess performance in terms of:
#     consistency and statistical efficiency,
#     accuracy of standard errors, 
#     computation time,
#     algorithm convergence,
#     robustness to the outcome distribution, and
#     robustness to the distribution of covariates and parameters,
# for a negative-binomial generalized bilinear model (NB-GBM) with log(E(Y)) = XA' + BZ' + XCZ' + UDV'.


# Each section of simulations is enclosed by an "if" block that can be enabled by using "if true" or disabled by using "if false".


using Distributions
using PyPlot
using LinearAlgebra
using DataFrames
using SpecialFunctions
using Random
using DelimitedFiles
include("gbm.jl")


# _________________________________________________________________________________________________
# General settings

J = 100  # 100  # number of samples
K = 4  # 4    # number of feature covariates
L = 2  # 2    # number of sample covariates
M = 3  # 3    # number of latent factors to use in model
M0 = M        # true number of latent factors
odist = "NegativeBinomial"  # true outcome distribution to use for generating the data
    # Choose from NegativeBinomial, Poisson, Geometric, LogNormalPoisson
cdist = "Normal"
    # Choose from Normal, Bernoulli, Gamma
pdist = "Normal"
    # Choose from Normal, Gamma


M0str = (M==M0 ? "" : "M0=$M0-")
results_dir = "results-J=$J-K=$K-L=$L-M=$M-$(M0str)$odist-$cdist-$pdist"
if !isdir(results_dir); mkdir(results_dir); end

rc("font", family="Georgia")


# _________________________________________________________________________________________________
# Helper functions

# NegativeBinomial distribution with mean=mu and dispersion=alpha 
#   r = 1/alpha  # number of failures until stopping
#   p = (1/alpha)/(mu+1/alpha)  # success probability
# Note that Julia uses the Wolfram definition which is that r is the number of successes until stopping.
NegBin(mu,alpha) = NegativeBinomial(1/alpha, (1/alpha)/(mu + 1/alpha))

# Standardize x to zero mean, unit variance
center_scale(x,dim=1) = (z = x .- mean(x,dims=dim); z./sqrt.(mean(z.^2,dims=dim)))

# Enforce bound on absolute values of x
bound(x,maxabsval) = max(min(x,maxabsval),-maxabsval)

# Simulate a covariance matrix using copula model
function simulate_covariate_matrix(I,K; maxabsval=100, cdist="Normal")
    if cdist=="Normal"
        cdistn = Normal()
    elseif cdist=="Bernoulli"
        cdistn = Bernoulli()
    elseif cdist=="Gamma"
        cdistn = Gamma(2,1/sqrt(2))
    else
        @error("Unknown value of cdist for simulating data.")
    end
    
    if cdist=="Normal"
        X = randn(I,K)*randn(K,K)
    else
        # The following line is mathematically equivalent to the approach used, and is algorithmically identical to the Normal case due to the use of center_scale:
        # W = randn(I,K); Q = randn(K,K); C = Q'*Q; sigma = sqrt.(diag(C)); X = (W*Q)./sigma'
    
        Q = randn(K,K); C = Q'*Q; sigma = sqrt.(diag(C)); C = (C./sigma)./sigma'; C = (C+C')/2  # generate a random correlation matrix
        X = rand(MvNormal(C),I)'  # feature covariates
        X = quantile.(cdistn,cdf.(Normal(),X))  # copula transformation
    end
    X = bound.(X,maxabsval)  # enforce bound on magnitude
    X[:,1] .= 1.0  # constant for intercepts
    X[:,2:end] = center_scale(X[:,2:end],1)  # standardize the covariates
    return X
end

# This seems to fix a weird bug in pinv that causes it to occasionally fail.
pinv__(X) = (try return pinv(X); catch; return pinv(X); end)
pinv_(X) = (pinv_X = pinv__(X); (any(isnan.(pinv_X)) ? pinv__(X) : pinv_X))

# Simulate true parameters and data
function simulate_parameters_and_data(I,J,K,L,M; maxabsval=100, omega0=-2.3, odist="NegativeBinomial", cdist="Normal", pdist="Normal")
    if pdist=="Normal"
        pdistn = Normal()
    elseif pdist=="Gamma"
        pdistn = Gamma(2,1/sqrt(2))
    else
        @error("Unknown value of pdist for simulating data.")
    end
    
    # Simulate covariates
    X = simulate_covariate_matrix(I,K; maxabsval=100, cdist=cdist)  # feature covariates
    Z = simulate_covariate_matrix(J,L; maxabsval=100, cdist=cdist)  # sample covariates

    # Simulate parameters
    A0 = rand(pdistn,J,K)/(2*sqrt(K))  # true feature coefficients
    B0 = rand(pdistn,I,L)/(2*sqrt(L))  # true sample coefficients
    C0 = rand(pdistn,K,L)/sqrt(K*L); if K>0; C0[1,1] = C0[1,1] + 3.0; end  # true intercepts and interaction coefficients
    B0 = B0 - X*(pinv_(X)*B0)  # enforce constraint that X'*B = 0 by projecting onto nullspace of X'.
    A0 = A0 - Z*(pinv_(Z)*A0)  # enforce constraint that Z'*A = 0 by projecting onto nullspace of Z'.
    
    U0 = Matrix(qr(randn(I,M)).Q)  # generate U0 uniformly from the Stiefel manifold
    V0 = Matrix(qr(randn(J,M)).Q)  # generate V0 uniformly from the Stiefel manifold
    if M > 0
        U0 = U0 - X*(pinv_(X)*U0)  # enforce constraint that X'*U = 0 by projecting onto nullspace of X'.
        V0 = V0 - Z*(pinv_(Z)*V0)  # enforce constraint that Z'*V = 0 by projecting onto nullspace of Z'.
    end
    D0 = (sqrt(I)+sqrt(J))*(collect(0:M-1)/max(M-1,1) .+ 1)  # use evenly spaced D values following the Marchenko-Pastur scaling
    
    # omega0 = true overall log-dispersion
    S0 = randn(I,1); S0 = S0 .- log(mean(exp.(S0)))  # true feature-specific log-dispersion offsets
    T0 = randn(J,1); T0 = T0 .- log(mean(exp.(T0)))  # true sample-specific log-dispersion offsets

    # Simulate data
    Mu0 = exp.(X*A0' + B0*Z' + X*C0*Z' + U0*(D0.*V0'))
    alpha0 = exp.(S0.+T0'.+omega0)
    if odist=="NegativeBinomial"
        Y = rand.(NegBin.(Mu0,alpha0))
    elseif odist=="Poisson"
        Y = rand.(Poisson.(Mu0))
    elseif odist=="Geometric"
        Y = rand.(Geometric.(1.0./(Mu0 .+ 1)))
    elseif odist=="LogNormalPoisson"
        Sigma2 = log.(alpha0 .+ 1)
        epsilon = rand.(Normal.(-0.5*Sigma2, sqrt.(Sigma2)))
        Y = rand.(Poisson.(Mu0.*exp.(epsilon)))
    else
        @error("Unknown value of odist for simulating data.")
    end
    
    return Y,X,Z,A0,B0,C0,D0,U0,V0,S0,T0,omega0
end


# Match up latent dimensions and latent factor signs
function permute_to_match_latent_dimensions!(D,U,V,D0,U0,V0)
    M = length(D)
    D1,U1,V1 = copy(D),copy(U),copy(V)
    mlist0 = collect(1:M)
    mlist1 = collect(1:M)
    for m = 1:M
        Cor = cor(U0[:,mlist0],U1[:,mlist1])
        index = findmax(abs.(Cor))[2]
        i0,i1 = index[1],index[2]
        sgn = sign(Cor[i0,i1])
        m0,m1 = mlist0[i0],mlist1[i1]
        U[:,m0] = U1[:,m1]*sgn
        V[:,m0] = V1[:,m1]*sgn
        D[m0] = D1[m1]
        deleteat!(mlist0,i0)
        deleteat!(mlist1,i1)
    end
end

# Make a plot of estimated versus true values
function plot_est_vs_true(x0,x,titletext; sp=0, se=0*x, zs=false, options...)
    if sp > 0
        subplots_adjust(hspace=0.4,top=0.95,bottom=0.08)
        subplot(sp)
    end
    if zs
        x = copy((x .- x0)./se)
        se = ones(size(se))
    end
    if any(se.!=0)
        for j=1:size(x,1), k=1:size(x,2)
            plot(x0[j,k]*[1,1], x[j,k] .+ 2*se[j,k]*[-1,1], "k-", lw=0.1)
        end
    end
    plot(x0[:],x[:],"r."; options...)
    if !zs
        xl,xu = min(xlim()[1],ylim()[1]), max(xlim()[2],ylim()[2])
        plot([xl,xu],[xl,xu], "k--", lw=0.5)
        xlim(xl,xu); ylim(xl,xu)
        yticks(xticks()[1])
        xlim(xl,xu); ylim(xl,xu)
    end
    grid(linewidth=0.25)
    xlabel("true"); ylabel("estimated")
    title(titletext)
end


# _________________________________________________________________________________________________
# Micro-run to precompile functions
if true

Random.seed!(0)
Y,X,Z,A0,B0,C0,D0,U0,V0,S0,T0,omega0 = simulate_parameters_and_data(20,10,K,L,M; odist=odist, cdist=cdist, pdist=pdist)
A,B,C,D,U,V,S,T,omega,logp = gbm_estimation(Y,X,Z,M; verbose=false)
se_A,se_B,se_C,se_D,se_U,se_V,se_S,se_T = gbm_inference(Y,X,Z,A,B,C,D,U,V,S,T,omega)

end

# _________________________________________________________________________________________________
# Computation time

if false
@assert(M==M0, "M must be equal to M0 for this part.")

nreps = 10
Is = round.(Int, 10.0.^(2.0 : 0.5 : 4.0))  # number of features
Js = [15,30,60,120,240]  # number of samples
n_iterations = 50
shapes = "os^vX*"

if true  # Generate results for estimation computation time
    for (i_J,J) in enumerate(Js)
        computation_time = zeros(nreps,length(Is))
        for (i_I,I) in enumerate(Is)
            println("____________ (Computation time for estimation) I = $I, J = $J, K = $K, L = $L, M = $M ____________")
            for rep = 1:nreps
                Random.seed!(rep)
                elapsed_time = 0.0
                Y,X,Z,A0,B0,C0,D0,U0,V0,S0,T0,omega0 = simulate_parameters_and_data(I,J,K,L,M; odist=odist, cdist=cdist, pdist=pdist)
                elapsed_time = (@elapsed gbm_estimation(Y,X,Z,M; max_iterations=n_iterations, tolerance=0.0, verbose=false))
                computation_time[rep,i_I] = elapsed_time / n_iterations
                println("    rep $rep: ",computation_time[rep,i_I]," seconds per iteration")
            end
            println("(I = $I, J = $J)  Average time per iteration: ",mean(computation_time[:,i_I])," seconds")
        end
        writedlm(results_dir*"/computation-time-for-estimation-J=$J.tsv",[permutedims(["nreps\\I"; collect(Is)]); [collect(1:nreps) computation_time]])
    end
end

# Plot
figure(1,figsize=(5.5,2.5)); clf(); grid(linewidth=0.45)
subplots_adjust(left=0.15,bottom=0.2,right=0.8)
for (i_J,J) in enumerate(Js)
    data,header = readdlm(results_dir*"/computation-time-for-estimation-J=$J.tsv"; header=true)
    Is1 = [parse(Int,header[k]) for k=2:length(header)]
    @assert(all(Is1.==Is))
    computation_time = data[:,2:end]
    loglog(Is, vec(mean(computation_time; dims=1)), shapes[i_J]*"-", label="J = $J")
end
title("Estimation time versus data matrix size")
xlabel("I  (# of features)")
ylabel("time per iteration (sec)")
legend(numpoints=1,bbox_to_anchor=(1.02, 0.9), loc=2, borderaxespad=0.)
savefig(results_dir*"/computation-time-for-estimation.png", dpi=200)


if true  # Generate results for inference computation time
    for (i_J,J) in enumerate(Js)
        computation_time = zeros(nreps,length(Is))
        for (i_I,I) in enumerate(Is)
            println("____________ (Computation time for inference) I = $I, J = $J, K = $K, L = $L, M = $M ____________")
            for rep = 1:nreps
                Random.seed!(rep)
                elapsed_time = 0.0
                Y,X,Z,A0,B0,C0,D0,U0,V0,S0,T0,omega0 = simulate_parameters_and_data(I,J,K,L,M; odist=odist, cdist=cdist, pdist=pdist)
                A,B,C,D,U,V,S,T,omega,logp = gbm_estimation(Y,X,Z,M; verbose=false)
                computation_time[rep,i_I] = (@elapsed gbm_inference(Y,X,Z,A,B,C,D,U,V,S,T,omega))
                println("    (rep $rep: ",computation_time[rep,i_I]," seconds)")
            end
            println("(I = $I, J = $J)  Average time: ",mean(computation_time[:,i_I])," seconds")
        end
        writedlm(results_dir*"/computation-time-for-inference-J=$J.tsv",[permutedims(["reo\\I"; collect(Is)]); [collect(1:nreps) computation_time]])
    end
end

# Plot
figure(2,figsize=(5.5,2.5)); clf(); grid(linewidth=0.45)
subplots_adjust(left=0.15,bottom=0.2,right=0.8)
for (i_J,J) in enumerate(Js)
    data,header = readdlm(results_dir*"/computation-time-for-inference-J=$J.tsv"; header=true)
    Is1 = [parse(Int,header[k]) for k=2:length(header)]
    computation_time = data[:,2:end]
    loglog(Is1, vec(mean(computation_time; dims=1)), shapes[i_J]*"-", label="J = $J")
end
title("Inference time versus data matrix size")
xlabel("I  (# of features)")
ylabel("time (sec)")
legend(numpoints=1,bbox_to_anchor=(1.02, 0.9), loc=2, borderaxespad=0.)
savefig(results_dir*"/computation-time-for-inference.png", dpi=200)


end



# _________________________________________________________________________________________________
# Algorithm convergence rate

if false

close("all")
@assert(M==M0, "M must be equal to M0 for this part.")

nreps = 25
Is = round.(Int, 10.0.^(2.0 : 1.0 : 4.0))  # number of features
n_iterations = 50

if true  # Generate results file
    println("\n Algorithm convergence rate")
    for (i_I,I) in enumerate(Is)
        logp_results = zeros(nreps,n_iterations)
        for rep = 1:nreps
            println("____________ (Algorithm convergence rate) I = $I, J = $J, K = $K, L = $L, M = $M, rep = $rep of $nreps ____________")
            Random.seed!(rep)
            Y,X,Z,A0,B0,C0,D0,U0,V0,S0,T0,omega0 = simulate_parameters_and_data(I,J,K,L,M; odist=odist, cdist=cdist, pdist=pdist)
            A,B,C,D,U,V,S,T,omega,logp = gbm_estimation(Y,X,Z,M; max_iterations=n_iterations, tolerance=0.0, verbose=true)
            logp_results[rep,:] = logp
        end
        writedlm(results_dir*"/algorithm-convergence-I=$I-J=$J.tsv",[permutedims(["rep\\iteration"; collect(1:n_iterations)]); [collect(1:nreps) logp_results]])
    end
end

# Plot
n_show = 20
for (i_I,I) in enumerate(Is)
    data,header = readdlm(results_dir*"/algorithm-convergence-I=$I-J=$J.tsv"; header=true)
    logp_results = data[:,2:end]
    figure(3,figsize=(5.5,2.5)); clf(); grid(linewidth=0.25)
    subplots_adjust(left=0.15,bottom=0.2,right=0.6)
    for rep = 1:nreps
        plot(1:n_show, logp_results[rep,1:n_show] .- maximum(logp_results[rep,:]), "-", lw=0.75)
    end
    # title("Log posterior density versus iteration (I = $I, J = $J)")
    title("I = $I, J = $J")
    xlabel("iteration")
    ylabel("log posterior + const")  # note that this is the log posterior up to an additive constant
    savefig(results_dir*"/algorithm-convergence-I=$I-J=$J.png", dpi=200)
end

end



# _________________________________________________________________________________________________
# Consistency and efficiency

if true
close("all")

mode = 1   # 1: initialize normally, 2: initialize at the true parameters, 3: compare to initializing at the true parameters
if mode in [1,2]
    nreps = 50  # number of replicate simulations to run
    Is = round.(Int, 10.0.^(2.0 : 0.5 : 4.0))  # number of features
else
    nreps = 50  # number of replicate simulations to run
    Is = round.(Int, 10.0.^(2.0 : 1.0 : 4.0))  # number of features
end
tolerance = 1e-8  # convergence tolerance for algorithm
shapes = "os^vX*"
variable_names = ["A","B","C","D","U","V","S","T","omega"]

# Function to compute the relative mean-squared error
relative_mse(x,y) = sum((x - y).^2)/sum(y.^2)

modestr = (mode==3 ? "_inittest" : "")

if true  # Generate consistency/efficiency results
    err = Dict{String,Matrix{Float64}}()
    for varname in variable_names
        err[varname] = zeros(nreps,length(Is))
    end
    for (i_I,I) in enumerate(Is)
        for rep = 1:nreps
            println("____________ (Consistency and efficiency) I = $I, J = $J, K = $K, L = $L, M = $M, rep = $rep of $nreps ____________")
            Random.seed!(rep)
            Y,X,Z,A0,B0,C0,D0,U0,V0,S0,T0,omega0 = simulate_parameters_and_data(maximum(Is),J,K,L,M0; odist=odist, cdist=cdist, pdist=pdist)
            logMu0 = X*A0' + B0*Z' + X*C0*Z' + U0*(D0.*V0')
            Y = Y[1:I,1:J]
            logMu0 = logMu0[1:I,1:J]
            X = X[1:I,:]
            Z = Z[1:J,:]
            A0,B0,C0,D0,U0,V0 = recover_parameters(logMu0,X,Z,M0)
            S0 = S0[1:I,:]
            T0 = T0[1:J,:]
            
            if mode==1
                A,B,C,D,U,V,S,T,omega,logp = gbm_estimation(Y,X,Z,M; tolerance=tolerance, verbose=true)
                println("omega = ",omega)
            elseif mode==2
                @assert(M==M0, "M must be equal to M0 for mode 2.")
                true_params = (A0,B0,C0,D0,U0,V0,S0,T0,omega0)
                A,B,C,D,U,V,S,T,omega,logp = gbm_estimation(Y,X,Z,M; tolerance=tolerance, verbose=true, init_params=true_params)
            elseif mode==3
                @assert(M==M0, "M must be equal to M0 for mode 3.")
                println("_____ Initialize at true parameters _____")
                true_params = (A0,B0,C0,D0,U0,V0,S0,T0,omega0)
                A0,B0,C0,D0,U0,V0,S0,T0,omega0,logp = gbm_estimation(Y,X,Z,M; tolerance=tolerance, verbose=true, init_params=true_params)
                println("_____ Initialize normally _____")
                A,B,C,D,U,V,S,T,omega,logp = gbm_estimation(Y,X,Z,M; tolerance=tolerance, verbose=true)
            else
                @error("Unknown value of mode")
            end
            
            println("Sum of squares:")
            println("    SS(XA') = ",SS(X*A'))
            println("    SS(BZ') = ",SS(B*Z'))
            println("    SS(XCZ') = ",SS(X*C*Z'))
            println("    SS(UDV') = ",SS(U*(D.*V')))
            println()
            
            if M==M0
                permute_to_match_latent_dimensions!(D,U,V,D0,U0,V0)
            end
            
            err["A"][rep,i_I] = relative_mse(A, A0)
            err["B"][rep,i_I] = relative_mse(B, B0)
            err["C"][rep,i_I] = relative_mse(C, C0)
            if M==M0
                err["D"][rep,i_I] = relative_mse(D, D0)
                err["U"][rep,i_I] = relative_mse(U, U0)
                err["V"][rep,i_I] = relative_mse(V, V0)
            end
            err["S"][rep,i_I] = relative_mse(exp.(S), exp.(S0))
            err["T"][rep,i_I] = relative_mse(exp.(T), exp.(T0))
            err["omega"][rep,i_I] = relative_mse(omega, omega0)
            
            figure(1,figsize=(12,7)); clf()
            plot_est_vs_true(A0[:],A[:],"A (err = $(round(relative_mse(A,A0),digits=3)))"; sp=331, ms=1.5)
            plot_est_vs_true(B0[:],B[:],"B (err = $(round(relative_mse(B,B0),digits=3)))"; sp=332, ms=1.5)
            plot_est_vs_true(C0[:],C[:],"C (err = $(round(relative_mse(C,C0),digits=3)))"; sp=333)
            if M==M0
                plot_est_vs_true(U0[:],U[:],"U (err = $(round(relative_mse(U,U0),digits=3)))"; sp=334, ms=1.5)
                plot_est_vs_true(V0[:],V[:],"V (err = $(round(relative_mse(V,V0),digits=3)))"; sp=335, ms=1.5)
                plot_est_vs_true(D0[:],D[:],"D (err = $(round(relative_mse(D,D0),digits=3)))"; sp=336)
            end
            plot_est_vs_true(S0[:],S[:],"S (err = $(round(relative_mse(S,S0),digits=3)))"; sp=337, ms=1.5)
            plot_est_vs_true(T0[:],T[:],"T (err = $(round(relative_mse(T,T0),digits=3)))"; sp=338, ms=1.5)
            subplot(339); plot(T0[:],(T-T0)[:],"r.",ms=1.5); title("T-T0 vs T0"); grid(linewidth=0.25)
            
            if (rep==1)
                se_A,se_B,se_C,se_D,se_U,se_V,se_S,se_T = gbm_inference(Y,X,Z,A,B,C,D,U,V,S,T,omega)
                
                figure(2,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
                plot_est_vs_true(A0[:],A[:],"A"; ms=2.5, se=se_A[:]); savefig(results_dir*"/scatterplot_A-I=$I-J=$J-rep=$rep.png",dpi=200); clf()
                plot_est_vs_true(B0[:],B[:],"B"; ms=2.5, se=se_B[:]); ylabel(""); savefig(results_dir*"/scatterplot_B-I=$I-J=$J-rep=$rep.png",dpi=200); clf()
                plot_est_vs_true(C0[:],C[:],"C"; se=se_C[:]); savefig(results_dir*"/scatterplot_C-I=$I-J=$J-rep=$rep.png",dpi=200); clf()
                if M==M0
                    plot_est_vs_true(D0[:],D[:],"D"); ylabel(""); savefig(results_dir*"/scatterplot_D-I=$I-J=$J-rep=$rep.png",dpi=200); clf()
                    plot_est_vs_true(U0[:],U[:],"U"; ms=2.5, se=se_U[:]); ylabel("");  savefig(results_dir*"/scatterplot_U-I=$I-J=$J-rep=$rep.png",dpi=200); clf()
                    plot_est_vs_true(V0[:],V[:],"V"; ms=2.5, se=se_V[:]); ylabel(""); savefig(results_dir*"/scatterplot_V-I=$I-J=$J-rep=$rep.png",dpi=200); clf()
                end
                plot_est_vs_true(S0[:],S[:],"S"; ms=2.5, se=se_S[:]); ylabel(""); savefig(results_dir*"/scatterplot_S-I=$I-J=$J-rep=$rep.png",dpi=200); clf()
                plot_est_vs_true(T0[:],T[:],"T"; ms=2.5, se=se_T[:]); ylabel(""); savefig(results_dir*"/scatterplot_T-I=$I-J=$J-rep=$rep.png",dpi=200); clf()
                plot(S0[:],(S-S0)[:],"r.",ms=2.5); title("S - S0 vs S0"); xlabel("true"); ylabel("estimated - true"); xl,xu = xlim(); plot([xl,xu],[0,0], "k--", lw=0.5); xlim(xl,xu); grid(linewidth=0.25); savefig(results_dir*"/scatterplot_Sb-I=$I-J=$J-rep=$rep.png",dpi=200); clf()
                plot(T0[:],(T-T0)[:],"r.",ms=2.5); title("T - T0 vs T0"); xlabel("true"); ylabel("estimated - true"); xl,xu = xlim(); plot([xl,xu],[0,0], "k--", lw=0.5); xlim(xl,xu); grid(linewidth=0.25); savefig(results_dir*"/scatterplot_Tb-I=$I-J=$J-rep=$rep.png",dpi=200); clf()
            end
        end
    end
    for varname in variable_names
        writedlm(results_dir*"/err$(modestr)_$varname-J=$J.tsv",[permutedims(["nreps\\I"; collect(Is)]); [collect(1:nreps) err[varname]]])
    end
end

sciformat(x; digits=3) = (p=floor(Int,log10(x)); l=x/(10.0^p); rl=(digits>0 ? round(l; digits=digits) : round(Int,l)); (p==0 ? "$(rl)" : "$(rl)e$p"))

# Plot
if mode==3
    for varname in variable_names
        data,header = readdlm(results_dir*"/err$(modestr)_$varname-J=$J.tsv"; header=true)
        for (i_I,I) in enumerate(Is)
            figure(3,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
            grid(linewidth=0.25)
            Is1 = [parse(Int,header[k]) for k=2:length(header)]
            i_I1 = findfirst(Is1.==I)
            hist(data[:,i_I1+1]; bins=50)
            title("$varname (I = $I)")
            xlabel("relative MSE")
            savefig(results_dir*"/err$(modestr)_$varname-I=$I.png", dpi=200)
            if I==1000; println("$varname: ",maximum(data[:,i_I1+1])); end
        end
    end
else
    for varname in variable_names
        figure(3,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
        grid(linewidth=0.25)
        data,header = readdlm(results_dir*"/err$(modestr)_$varname-J=$J.tsv"; header=true)
        Is1 = [parse(Int,header[k]) for k=2:length(header)]
        for rep = 1:size(data,1)
            loglog(Is1, data[rep,2:end], "-", lw=0.25)
        end
        loglog(Is1, vec(median(data[:,2:end]; dims=1)), "bo-", label="J = $J")
        yl,yu = ylim()
        yt = yticks()[1]
        
        # format major ticks
        yticks(yt,sciformat.(yt; digits=0))
        ylim(yl,yu)
        pause(0.1)
        
        # format minor ticks
        ax = gca()
        mask = [isempty(t.get_text()) for t in ax.yaxis.get_minorticklabels()]
        locs = ax.yaxis.get_minorticklocs()
        labels = [(mask[i] ? "" : sciformat(locs[i]; digits=0)) for i=1:length(locs)]
        ax.yaxis.set_ticklabels(labels,minor=true)
        
        ax.xaxis.set_tick_params(which="both",labelsize=11)
        ax.yaxis.set_tick_params(which="both",labelsize=11)

        ylim(yl,yu)
        title(varname)
        xlabel("I  (# of features)")
        ylabel("relative MSE")
        if varname=="omega"; ylim(1e-6, ylim()[2]); end
        savefig(results_dir*"/err$(modestr)_$varname.png", dpi=200)
    end
end

end



# _________________________________________________________________________________________________
# Calibration and coverage

if true
close("all")

nreps = 50  # number of replicate simulations to run
tolerance = 1e-8  # convergence tolerance for algorithm
Is = round.(Int, 10.0.^(2.0 : 1.0 : 4.0))  # number of features

if true  # Generate results files
    for (i_I,I) in enumerate(Is)

        vnames_and_sizes = [("A",J*K),("B",I*L),("C",K*L),("U",I*M),("V",J*M),("D",M),("S",I),("T",J)]
        zscores = Dict{String,Matrix{Float64}}()
        for (varname,siz) in vnames_and_sizes
            zscores[varname] = zeros(siz,nreps)
        end
        T0_r = zeros(J,nreps)
        T_r = zeros(J,nreps)
        
        if true  # Generate results file
            for rep = 1:nreps
                println("____________ (Calibration and coverage) I = $I, J = $J, K = $K, L = $L, M = $M, rep = $rep of $nreps ____________")
                Random.seed!(rep)
                
                Y,X,Z,A0,B0,C0,D0,U0,V0,S0,T0,omega0 = simulate_parameters_and_data(I,J,K,L,M0; odist=odist, cdist=cdist, pdist=pdist)
                
                # Estimation and inference
                println("Performing estimation...")
                A,B,C,D,U,V,S,T,omega,logp = gbm_estimation(Y,X,Z,M; tolerance=tolerance, verbose=true)
                println("omega = ",omega)
                
                println("Checking constraints...")
                check_constraints(Y,X,Z,A,B,C,D,U,V,S,T)
                
                # Match latent dimensions and latent factor signs
                if M==M0
                    permute_to_match_latent_dimensions!(D,U,V,D0,U0,V0)
                end
                
                println("Performing inference ...")
                se_A,se_B,se_C,se_D,se_U,se_V,se_S,se_T = gbm_inference(Y,X,Z,A,B,C,D,U,V,S,T,omega)
                
                if true
                figure(1,figsize=(12,7)); clf()
                plot_est_vs_true(A0[:],A[:],"A"; sp=331, ms=1.5)
                plot_est_vs_true(B0[:],B[:],"B"; sp=332, ms=1.5)
                plot_est_vs_true(C0[:],C[:],"C"; sp=333)
                if M==M0
                    plot_est_vs_true(U0[:],U[:],"U"; sp=334, ms=1.5)
                    plot_est_vs_true(V0[:],V[:],"V"; sp=335, ms=1.5)
                    plot_est_vs_true(D0[:],D[:],"D"; sp=336)
                end
                plot_est_vs_true(S0[:],S[:],"S"; sp=337, ms=1.5)
                plot_est_vs_true(T0[:],T[:],"T"; sp=338, ms=1.5, se=se_T[:])
                end
                
                # Record z-scores
                zscores["A"][:,rep] = vec(((A - A0)./se_A)')
                zscores["B"][:,rep] = vec(((B - B0)./se_B)')
                zscores["C"][:,rep] = vec((C - C0)./se_C)
                if M==M0
                    zscores["D"][:,rep] = vec(((D - D0)./se_D))
                    zscores["U"][:,rep] = vec(((U - U0)./se_U)')
                    zscores["V"][:,rep] = vec(((V - V0)./se_V)')
                end
                zscores["S"][:,rep] = vec((S - S0)./se_S)
                zscores["T"][:,rep] = vec((T - T0)./se_T)
                
                # Record true values and estimates for T
                T0_r[:,rep] = T0
                T_r[:,rep] = T
            end
            for (varname,siz) in vnames_and_sizes
                writedlm(results_dir*"/zscores_$varname-I=$I-J=$J-nreps=$nreps.tsv", zscores[varname])
            end
            writedlm(results_dir*"/T0-I=$I-J=$J-nreps=$nreps.tsv", T0_r)
            writedlm(results_dir*"/T-I=$I-J=$J-nreps=$nreps.tsv", T_r)
        end
        
        # Plot coverage
        figure(2,figsize=(12,7)); clf()
        subplots_adjust(hspace=0.4,top=0.95,bottom=0.08)
        for (i_v,(varname,siz)) in enumerate(vnames_and_sizes)
            if (varname in ["U","V","D"]) && ((M==0) || (M!=M0)); continue; end
            subplot(3,3,i_v)
            zscores_varname = zscores[varname]
            if varname=="C"; zscores_varname = zscores_varname[2:end,:]; end  # exclude C[1,1] in calculation of coverage
            c = 1.0 .- 2*(1.0 .- cdf.(Normal(0,1), abs.(vec(zscores_varname))))
            plot(sort(c), ((1:length(c)) .- 0.5)/length(c))
            plot([0,1],[0,1],"k-",lw=0.25)
            title(varname)
            ylabel("actual coverage")
            xlabel("target coverage")
            grid(linewidth=0.25)
            xlim(0,1); ylim(0,1)
        end
        
        # QQ-plot
        figure(3,figsize=(12,7)); clf()
        subplots_adjust(hspace=0.4,top=0.95,bottom=0.08)
        for (i_v,(varname,siz)) in enumerate(vnames_and_sizes)
            if (varname in ["U","V","D"]) && ((M==0) || (M!=M0)); continue; end
            subplot(3,3,i_v)
            zscores_varname = zscores[varname]
            if varname=="C"; zscores_varname = zscores_varname[2:end,:]; end  # exclude C[1,1] in calculation of coverage
            zs = sort(vec(zscores_varname))
            plot(((1:length(zs)).-0.5)/length(zs), cdf.(Normal(0,1),zs))
            plot([0,1],[0,1],"k-",lw=0.25)
            title(varname)
            ylabel("actual")
            xlabel("target")
            grid(linewidth=0.25)
            xlim(0,1); ylim(0,1)
        end
        
        # Plot p-value CDFs
        figure(4,figsize=(12,7)); clf()
        subplots_adjust(hspace=0.4,top=0.95,bottom=0.08)
        for (i_v,(varname,siz)) in enumerate(vnames_and_sizes)
            if (varname in ["U","V","D"]) && ((M==0) || (M!=M0)); continue; end
            subplot(3,3,i_v)
            zscores_varname = zscores[varname]
            if varname=="C"; zscores_varname = zscores_varname[2:end,:]; end  # exclude C[1,1] in calculation of p-values
            p = 2*ccdf.(Normal(0,1), abs.(vec(zscores_varname)))
            plot(sort(p), ((1:length(p)) .- 0.5)/length(p))
            plot([0,1],[0,1],"k--",lw=0.5)
            title("p-value CDF for $varname")
            ylabel("CDF")
            xlabel("p-value")
            grid(linewidth=0.25)
            xlim(0,1); ylim(0,1)
        end
    end
end

# Plot coverage
variable_names = ["A","B","C","D","U","V","S","T"]
linestyles = ["-","-.","--"]
for varname in variable_names
    if (varname in ["U","V","D"]) && ((M==0) || (M!=M0)); continue; end
    figure(5,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
    for (i_I,I) in enumerate(Is)
        zscores_varname = readdlm(results_dir*"/zscores_$varname-I=$I-J=$J-nreps=$nreps.tsv")
        if varname=="C"; zscores_varname = zscores_varname[2:end,:]; end  # exclude C[1,1] in calculation of coverage
        c = 1.0 .- 2*(1.0 .- cdf.(Normal(0,1), abs.(vec(zscores_varname))))
        plot(sort(c), ((1:length(c)) .- 0.5)/length(c), linestyles[i_I], lw=1, label="I = $I")
    end
    plot([0,1],[0,1],"k-",lw=0.25)
    title(varname)
    ylabel("actual coverage")
    xlabel("target coverage")
    grid(linewidth=0.25)
    xlim(0,1); ylim(0,1)
    legend()
    savefig(results_dir*"/coverage_$varname-J=$J-nreps=$nreps.png",dpi=200)
end

# QQ-plot
variable_names = ["A","B","C","D","U","V","S","T"]
linestyles = ["-","-.","--"]
for varname in variable_names
    if (varname in ["U","V","D"]) && ((M==0) || (M!=M0)); continue; end
    figure(6,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
    for (i_I,I) in enumerate(Is)
        zscores_varname = readdlm(results_dir*"/zscores_$varname-I=$I-J=$J-nreps=$nreps.tsv")
        if varname=="C"; zscores_varname = zscores_varname[2:end,:]; end  # exclude C[1,1] in calculation of QQ-plot
        zs = sort(vec(zscores_varname))
        plot(((1:length(zs)).-0.5)/length(zs), cdf.(Normal(0,1),zs), linestyles[i_I], lw=1, label="I = $I")
    end
    plot([0,1],[0,1],"k-",lw=0.25)
    title(varname)
    ylabel("actual")
    xlabel("target")
    grid(linewidth=0.25)
    xlim(0,1); ylim(0,1)
    legend()
    savefig(results_dir*"/qqplot_$varname-J=$J-nreps=$nreps.png",dpi=200)
end


# Plot p-value CDFs
variable_names = ["A","B","C","D","U","V","S","T"]
linestyles = ["-","-.","--"]
for varname in variable_names
    if (varname in ["U","V","D"]) && ((M==0) || (M!=M0)); continue; end
    figure(7,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
    for (i_I,I) in enumerate(Is)
        zscores_varname = readdlm(results_dir*"/zscores_$varname-I=$I-J=$J-nreps=$nreps.tsv")
        if varname=="C"; zscores_varname = zscores_varname[2:end,:]; end  # exclude C[1,1] in calculation of p-values
        p = 2*ccdf.(Normal(0,1), abs.(vec(zscores_varname)))
        plot(sort(p), ((1:length(p)) .- 0.5)/length(p), linestyles[i_I], lw=1, label="I = $I")
    end
    plot([0,1],[0,1],"k-",lw=0.25)
    title(varname)
    ylabel("CDF")
    xlabel("p-value")
    grid(linewidth=0.25)
    xlim(0,1); ylim(0,1)
    legend()
    savefig(results_dir*"/pvalue_cdfs_$varname-J=$J-nreps=$nreps.png",dpi=200)
end



end


























