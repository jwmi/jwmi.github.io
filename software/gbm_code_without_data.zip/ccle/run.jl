# Analyze coverage data for CCLE whole-exome seq analysis

# To generate the results in the paper, run this file with the following four combinations of settings:
# (1) method="GBM"; generate_factors=true
# (2) method="GBM"; generate_factors=false
# (1) method="GATK"; generate_factors=true
# (2) method="GATK"; generate_factors=false

method = "GBM"  #  GBM or GATK
generate_factors = true  # true: generate latent factors using training data, false: use latent factors on testing data

# _________________________________________________________________________________________________
# Load functions

using CSV
using DataFrames
using Random
using DelimitedFiles
include("../splines.jl")
include("../helper.jl")
include("../gbm.jl")

using PyPlot
if ("OS" in keys(ENV)) && (ENV["OS"]=="Windows_NT")
    rc("font", family="Georgia")
    linux = false
else
    ioff(); 
    rc("font", family="DejaVu Serif", size=8)
    linux = true
end

# _________________________________________________________________________________________________
# Settings

runtag = ""  # tag to label results for run
M_gen = 5  # number of latent factors to use
color_by_precision = true


datasets = ["LCLL","LUSC","DLBC","HNSC","LGG","LIHC","MM","SKCM","COAD","PAAD","STAD","OV","BRCA","CESC","SARC","KIRC","BLCA","PRAD","ESCA","THCA","UCEC","MESO"]
subset_for_generating_factors = 0.5
presegment = generate_factors
update_T = !generate_factors
seg_gamma = 1000.0

datasetlabel = (length(datasets)==22 ? "ALLDATA" : join(datasets,"_"))
input_factors_file = "factors-$datasetlabel-M=$(M_gen).txt"
samples_to_exclude = []
M = (generate_factors ? M_gen : 0)  # number of latent factors to use

Random.seed!(0)

# _________________________________________________________________________________________________
# Load data

Y = convert(Matrix{Int}, CSV.read("counts-CCLE-$datasetlabel-WXS.tsv"; delim='\t')[!,4:end])
feature_info = CSV.read("feature_info.txt"; delim='\t')
sample_info = CSV.read("sample_info-$datasetlabel.txt"; delim='\t')


# Select a subset of features to use
nonzero_median = vec(median(Y; dims=2).>0)
in_autosome = subset_in(feature_info[!,:contig], string.(1:22))
features_to_use = (nonzero_median .& in_autosome)
Y = Y[features_to_use,:]
feature_info = feature_info[features_to_use,:]


# Select a subset of samples to use
nonexcluded_samples = .!subset_in(sample_info[!,:sample_id], samples_to_exclude)
if typeof(subset_for_generating_factors) == Float64
    samples_for_factors = subset_in(1:size(Y,2), shuffle(findall(nonexcluded_samples))[1:round(Int,subset_for_generating_factors*end)])
else
    samples_for_factors = subset_in(sample_info[!,:dataset], subset_for_generating_factors)
end
writedlm("training_set.txt",sample_info[samples_for_factors,:sample_id])
writedlm("testing_set.txt",sample_info[.!samples_for_factors,:sample_id])

if generate_factors
    samples_to_use = (nonexcluded_samples .& samples_for_factors)
else
    samples_to_use = (nonexcluded_samples .& .!samples_for_factors)
end
Y = Y[:,samples_to_use]
sample_info = sample_info[samples_to_use,:]

I,J = size(Y)



# _________________________________________________________________________________________________
# Model definition

if method=="GBM"

# Load factors to use as extra feature covariates
if !generate_factors
    D_extra = CSV.read(input_factors_file; delim='\t')
    X_extra = convert(Matrix{Float64}, D_extra[!,2:end])
    @assert(all(D_extra[!,:name].==feature_info[!,:name]))
else
    X_extra = zeros(size(Y,1),0)
end

# Compute additional feature covariates
feature_info[!,:GC_content] = (feature_info[!,:num_G] .+ feature_info[!,:num_C]) ./ feature_info[!,:length]


# Construct gene-specific design matrix
println("Constructing gene-specific design matrix...")
X_length = log.(feature_info[!,:length])
X_gc = [feature_info[!,:GC_content]  moment2(feature_info[!,:GC_content])]
X = [ones(I) X_length X_gc X_extra]
X[:,2:end] = scale(X[:,2:end],1)
K = size(X,2)


# Construct sample-specific design matrix
println("Constructing sample-specific design matrix...")
Z = ones(J,1)
Znames = ["(Intercept)"]
L = size(Z,2)

end


# _________________________________________________________________________________________________
# Run model


results_dir = "results-$datasetlabel" * (isempty(runtag) ? "" : "-$runtag") * "-$method-M_gen=$M_gen-gf=$(generate_factors)"
if !isdir(results_dir); mkdir(results_dir); end


# Basic CR estimates
pseudocount = 0.125
row_scaling = mean(Y.+pseudocount,dims=2)  # could alternatively use median here
Yrel = (Y.+pseudocount)./row_scaling
col_scaling = mean(Yrel,dims=1)
CR_basic = Yrel./col_scaling
logCR_basic = log.(CR_basic)


# Compute pre-segmentation offsets based on logCR_basic
if presegment
    seg_start = [findfirst(feature_info[!,:contig].==chr) for chr in unique(feature_info[!,:contig])]
    Seg = zeros(I,J)
    for j = 1:J
        sigma2 = var(diff(logCR_basic[:,j]))/2
        binary_segmentation!(view(Seg,:,j), view(logCR_basic,:,j), ones(I)/sigma2, seg_gamma; seg_start=copy(seg_start))
    end
else
    Seg = zeros(I,J)
end

# Desegmented counts
Y_deseg = round.(Int, (exp.(logCR_basic - Seg) .* col_scaling) .* row_scaling)


if method == "GBM"
    println("Estimating GBM parameters...")
    Y_use = (presegment ? Y_deseg : Y)
    
    @time A,B,C,D,U,V,S,T,omega,logp_r = gbm_estimation(Y_use,X,Z,M; verbose=true, update_T=update_T)

    # Compute GBM residuals
    logCR_model = adjusted_residuals(Y_use,X,Z,A,B,C,D,U,V)
    E,W,ss = compute_misc(Y_use,X,Z,A,B,C,D,U,V,S,T,omega)

    if generate_factors
        df = DataFrame(name=feature_info[!,:name])
        for m = 1:M; df[!,Symbol("factor$m")] = U[:,m]; end
        CSV.write("factors-$datasetlabel-M=$M.txt",df; delim='\t')
    end

elseif method == "GATK"

	if !isdir("gatk"); mkdir("gatk"); end
	if !isdir("preseg"); mkdir("preseg"); end
	if !isdir("gatk/results"); mkdir("gatk/results"); end

    ponfile = "gatk/pon.hdf5"
    
    println("Writing desegmented counts for GATK...")
    df = feature_info[!,1:3]    
    rename!(df, "contig"=>"CONTIG")
    rename!(df, "start"=>"START")
    rename!(df, "stop"=>"END")
    for j = 1:J
        sample_id = sample_info[!,:sample_id][j]
        println(sample_id)
        df[!,:COUNT] = Y_deseg[:,j] .+ 1   # add pseudocount of 1 to prevent GATK from crashing
        
        header = read("gatk/gatk_counts_header.txt",String)
        cellline = replace(sample_id[6:end-2], "_"=>" ")
        header_sample_line = join(["@RG","ID:GATKCopyNumber","SM:$cellline\n"],"\t")
        CSV.write("preseg/temp.txt",df; delim='\t')
        
        write("preseg/$(sample_id).counts.tsv", header * header_sample_line * read("preseg/temp.txt",String))
    end

    if generate_factors
        println("Writing arguments file for GATK...")
        argfile = "gatk/arguments_file.txt"
        f = open(argfile,"w")
        for j = 1:J
            sample_id = sample_info[!,:sample_id][j]
            write(f,"-I preseg/$(sample_id).counts.tsv ")
        end
        close(f)
        
        println("Computing GATK panel of normals...")
        ENV["LD_PRELOAD"] = "libopenblas.so"
        
        @time run(`gatk --java-options "-Xmx6500m" CreateReadCountPanelOfNormals 
                        --number-of-eigensamples 5
                        --arguments_file $argfile
                        --minimum-interval-median-percentile 0.0 
                        --maximum-zeros-in-interval-percentage 100.0 
                        -O $ponfile`)
    end
    
    println("Denoising using GATK panel of normals...")
    @time for j = 1:J
        sample_id = sample_info[!,:sample_id][j]
        println("\n\n__________________________________ $sample_id __________________________________\n")
        run(`gatk --java-options "-Xmx12g" DenoiseReadCounts 
                -I preseg/$(sample_id).counts.tsv
                --count-panel-of-normals $ponfile
                --standardized-copy-ratios gatk/results/$(sample_id).standardizedCR.tsv 
                --denoised-copy-ratios gatk/results/$(sample_id).denoisedCR.tsv`)
    end
    
    # Read latent factors that were generated
    using HDF5
    pon = h5open(ponfile,"r")                        
    panel = read(pon["panel"])
    U = panel["transposed_eigensamples_samples_by_intervals"]["chunk_0"]
    close(pon)
    
    # Read estimated log copy ratios
    logCR_model = zeros(I,J)
    for j = 1:J
        sample_id = sample_info[!,:sample_id][j]
        println(sample_id)
        fname = "gatk/results/$(sample_id).denoisedCR.tsv"
        df = CSV.read(fname; delim='\t', comment="@")
        logCR_model[:,j] = df[!,:LOG2_COPY_RATIO] * log(2)
    end
    
end



# _________________________________________________________________________________________________
# Plot results

contig_names = unique(feature_info[!,:contig])
edges = [1; findall(feature_info[!,:contig][1:I-1] .!= feature_info[!,:contig][2:I]); I]
mid = (edges[1:end-1] + edges[2:end])/2
o = collect(J:-1:1)


# Plot latent factors
for m = 1:M
    figure(4, figsize=(12,3)); clf()  
    subplots_adjust(left=0.1,bottom=0.1,right=0.97,top=0.9,hspace=0.2)
    grid(linewidth=0.25, axis="y")
    title("Latent factor $m")
    plot(U[:,m],"b,",ms=0.1)
    yl,yu = ylim()
    for edge in edges; plot([edge,edge],[yl,yu],"k-",lw=0.15); end
    ylim(yl,yu)
    xticks(mid,contig_names,fontsize=9)
    savefig("$results_dir/factor-$m.png",dpi=200)
end


function moving_average(x,width; weights=x.^0)
    n = length(x)
    hw = round(Int,width/2)
    avg = zeros(n)
    for i = 1:n
        S = max(1,i-hw):min(n,i+hw)
        avg[i] = sum(view(x,S).*view(weights,S))/sum(view(weights,S))
    end
    return avg
end

if method=="GBM"
    high_precision = zeros(Bool,I,J); for j=1:J; high_precision[:,j] = (W[:,j] .> moving_average(W[:,j],10)); end
end


# Local relative standard error metric
function rse_metric(x,weights,width)
    w = weights ./ moving_average(weights,width)
    mu = moving_average(x,width; weights=weights)
    v = mean((w.*(x - mu)).^2)
    return sqrt(v)
end

# MAD of moving average
function mad_metric(x,weights,width)
    mu = moving_average(x,width; weights=weights)
    mad = width*median(abs.(diff(mu)))
    return mad
end

# Compare RSE performance metric for model versus basic
width = 100
rse_basic = [rse_metric(logCR_basic[:,j],ones(I),width) for j=1:J]
rse_model = [rse_metric(logCR_model[:,j],(method=="GBM" ? W[:,j] : ones(I)),width) for j=1:J]
figure(5,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
grid(linewidth=0.25)
title("Local relative standard error")
plot(rse_basic,rse_model,"b.",ms=4,mec="k",mew=0.1)
xlabel("basic")
ylabel("model")
axis("square")
lb = 0 # min(xlim()[1],ylim()[1])
ub = max(xlim()[2],ylim()[2])*1.05
plot([lb,ub],[lb,ub],"k-",lw=0.5)
xlim(lb,ub); ylim(lb,ub)
savefig("$results_dir/rse.png",dpi=200)
CSV.write("$results_dir/rse.tsv",DataFrame(sample_id=sample_info[!,:sample_id], rse_basic=rse_basic, rse_model=rse_model); delim='\t')

# Compare MAD performance metric for model versus basic
width = 100
mad_basic = [mad_metric(logCR_basic[:,j],ones(I),width) for j=1:J]
mad_model = [mad_metric(logCR_model[:,j],(method=="GBM" ? W[:,j] : ones(I)),width) for j=1:J]
figure(5,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
grid(linewidth=0.25)
title("Weighted median absolute difference")
plot(mad_basic,mad_model,"b.",ms=4,mec="k",mew=0.1)
xlabel("basic")
ylabel("model")
axis("square")
lb = 0 # min(xlim()[1],ylim()[1])
ub = max(xlim()[2],ylim()[2])*1.05
plot([lb,ub],[lb,ub],"k-",lw=0.5)
xlim(lb,ub); ylim(lb,ub)
savefig("$results_dir/mad.png",dpi=200)
CSV.write("$results_dir/mad.tsv",DataFrame(sample_id=sample_info[!,:sample_id], mad_basic=mad_basic, mad_model=mad_model); delim='\t')

if false
rse_gbm = CSV.read("results-ALLDATA-GBM-M_gen=5-gf=false/rse.tsv"; delim='\t')[!,:rse_model]
rse_gatk = CSV.read("results-ALLDATA-GATK-M_gen=5-gf=false/rse.tsv"; delim='\t')[!,:rse_model]
mad_gbm = CSV.read("results-ALLDATA-GBM-M_gen=5-gf=false/mad.tsv"; delim='\t')[!,:mad_model]
mad_gatk = CSV.read("results-ALLDATA-GATK-M_gen=5-gf=false/mad.tsv"; delim='\t')[!,:mad_model]

# Plot RSE of GBM versus GATK
figure(5,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
grid(linewidth=0.25)
title("Local relative standard error")
plot(rse_gatk,rse_gbm,"b.",ms=4,mec="k",mew=0.1)
xlabel("GATK")
ylabel("GBM")
axis("square")
lb = 0 # min(xlim()[1],ylim()[1])
ub = max(xlim()[2],ylim()[2])*1.05
plot([lb,ub],[lb,ub],"k-",lw=0.5)
xticks(0:0.05:0.25); yticks(0:0.05:0.25)
xlim(lb,ub); ylim(lb,ub)
savefig("$results_dir/rse_GBM_vs_GATK.png",dpi=200)

# Plot MAD of GBM versus GATK
figure(5,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
grid(linewidth=0.25)
title("Weighted median absolute difference")
plot(mad_gatk,mad_gbm,"b.",ms=4,mec="k",mew=0.1)
xlabel("GATK")
ylabel("GBM")
axis("square")
lb = 0 # min(xlim()[1],ylim()[1])
ub = max(xlim()[2],ylim()[2])*1.05
plot([lb,ub],[lb,ub],"k-",lw=0.5)
xticks(0:0.05:0.25); yticks(0:0.05:0.25)
xlim(lb,ub); ylim(lb,ub)
savefig("$results_dir/mad_GBM_vs_GATK.png",dpi=200)

CSV.write("$results_dir/metrics.tsv",DataFrame(sample_id=sample_info[!,:sample_id], rse_basic=rse_basic, rse_gbm=rse_gbm, rse_gatk=rse_gatk, mad_basic=mad_basic, mad_gbm=mad_gbm, mad_gatk=mad_gatk); delim='\t')

end


width = 3
logCR_model_smoothed = zeros(I,J)
for j = 1:J
    weights = (method=="GBM" ? W[:,j] : ones(I))
    logCR_model_smoothed[:,j] = moving_average(logCR_model[:,j],width; weights=weights)
end


# Plot heatmap
figure(1, figsize=(13,8)); clf()
subplots_adjust(left=0.1,bottom=0.15,right=0.95,top=0.92)
title("$method estimates of log2 copy ratios",fontsize=16)
Image = logCR_model_smoothed[:,o]' / log(2)
# vmax = maximum(abs.(quantile(Image[:],[0.01,0.99])))
vmax = 2.0
imshow(Image; vmax=vmax, vmin=-vmax, aspect="auto", cmap=PyPlot.cm_get_cmap("bwr"), interpolation="nearest")
# imshow(Image; aspect="auto", cmap=PyPlot.cm_get_cmap("bwr"))
ylabel("Sample",fontsize=13)
# xlabel("Target",fontsize=11)
if J <= 50; yticks(0:J-1,sample_info[!,:sample_id],fontsize=8); else; yticks(9:10:J-1, collect(10:10:J)); end
xticks(mid,contig_names,fontsize=10)
yl,yu = ylim()
for edge in edges; plot([edge,edge],[yl,yu],"k-",lw=0.5); end
ylim(yl,yu)
colorbar(fraction=0.01,pad=0.01)
savefig("$results_dir/heatmap-$method-smoothed.png",dpi=200)


sample_info[!,:tissue_string] = [(ismissing(t) ? "unknown tissue" : replace(t,"_"=>" ")) for t in sample_info[!,:tissue]]


# Plot total copy ratio estimates
for j = 1:J
    sample_id = sample_info[!,:sample_id][j]
    tissue = sample_info[!,:tissue_string][j]
    println(sample_id)
    
    figure(2, figsize=(12,2.5)); clf()  
    subplots_adjust(left=0.1,bottom=0.1,right=0.97,top=0.89,hspace=0.2)
    grid(linewidth=0.25, axis="y")
    title("Basic estimates ($sample_id, $tissue)",fontsize=14)
    ylabel("copy ratio",fontsize=11)
    plot(CR_basic[:,j],"b,",ms=0.1)
    yl,yu = 0,4
    for edge in edges; plot([edge,edge],[yl,yu],"k-",lw=0.15); end
    yticks(0:ceil(Int,yu))
    xlim(-1000,I+1000)
    ylim(yl,yu)
    xticks(mid,contig_names,fontsize=(linux ? 8 : 9))
    savefig("$results_dir/tcr-basic-sample-$j.png",dpi=200)
    
    figure(2, figsize=(12,3)); clf()  
    subplots_adjust(left=0.1,bottom=0.1,right=0.97,top=0.89,hspace=0.2)
    grid(linewidth=0.25, axis="y")
    title("$method estimates ($sample_id, $tissue)",fontsize=14)
    ylabel("copy ratio",fontsize=11)
    if (method=="GBM") && color_by_precision
        plot(findall(.!high_precision[:,j]), exp.(logCR_model[.!high_precision[:,j],j]), "c,",ms=0.1)
        plot(findall(high_precision[:,j]), exp.(logCR_model[high_precision[:,j],j]), "b,",ms=0.1)
    else
        plot(exp.(logCR_model[:,j]),"b,",ms=0.1)
    end
    for edge in edges; plot([edge,edge],[yl,yu],"k-",lw=0.15); end
    yticks(0:ceil(Int,yu))
    xlim(-1000,I+1000)
    ylim(yl,yu)
    xticks(mid,contig_names,fontsize=(linux ? 8 : 9))
    savefig("$results_dir/tcr-$method-sample-$j.png",dpi=200)
end














