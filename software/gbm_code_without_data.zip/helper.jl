# Miscellaneous functions

using PyPlot
using Distributions
using DataFrames
using GLM
using Statistics
using MultivariateStats
using Interpolations


# Color palette from https://sashat.me/2017/01/11/list-of-20-simple-distinct-colors/
# colors = ["#e6194b", "#3cb44b", "#0082c8", "#f58231", "#911eb4", "#46f0f0", "#f032e6", "#d2f53c", "#fabebe", "#008080", "#e6beff", "#aa6e28", "#fffac8", "#800000", "#aaffc3", "#808000", "#ffd8b1", "#000080", "#808080", "#ffe119", "#FFFFFF", "#000000"]

# Larger palette of 30 colors that I refined by hand a bit:
colors = ["#e6194b", "#3cb44b", "#0000b3", "#f58231", "#911eb4", "#46f0f0", "#f032e6", "#d2f53c", "#fabebe", "#008080", "#e6beff", "#aa6e28", "#fffac8", "#800000", "#aaffc3", "#808000", "#ffd8b1", "#0082c8", "#808080", "#edc61a", "#FFFFFF", "#000000", "#008040", "#6cb5d9", "#ace639", "#ccf5ff", "#aa79f2", "#FFFF00", "#c7d9a3", "#73341d"]

# List of PyPlot markers
markers = ["o","v","^","s","*","<",">","p","+","x","D","d","."]

# _________________________________________________________________________________________________
# Functions

rms(x) = sqrt(mean(x.^2))
rms(x,dim) = sqrt.(mean(x.^2,dims=dim))
avgdif(x,y) = ((x+y)/2, x-y)
scale(x,dim=1) = (x .- mean(x,dims=dim))./std(x,dims=dim)
unitscale(x,dim=1) = (z = x .- mean(x,dims=dim); z./sqrt.(sum(z.^2,dims=dim)))
ranks(x) = invperm(sortperm(x))
logit(p) = log.(p./(1-p))
moment2(x) = (x .- mean(x)).^2

# Make a plot of the empirical CDF of x
function plotcdf(x; log=false, kwargs...)
    n = length(x)
    if log; semilogx(sort(x), (1:n)/n; kwargs...)
    else; plot(sort(x), (1:n)/n; kwargs...)
    end
end

# Make a scatterplot of y versus x with points colored according to labels.
function plotgroups(x,y,labels;kwargs...)
    for (i_v,v) in enumerate(sort(unique(labels,dims=1)))
        subset = findall(labels.==v)
        col = colors[mod.(i_v-1,length(colors))+1]
        fmt = markers[div.(i_v-1,length(colors))+1]
        plot(x[subset],y[subset],fmt,label=v,color=col;kwargs...)
    end
end

# Make a scatterplot of the top two PCA scores
function pcaplot(E,labels=ones(Int,size(E,2));kwargs...)
    M = fit(PCA,E; maxoutdim=2)
    z = MultivariateStats.transform(M,E)
    # if size(z,1)<2; error("Rank of input is insufficient for 2 principal components."); end
    # figure(); clf(); grid(true)
    plotgroups(z[1,:],z[2,:],labels;kwargs...)
    xlabel("PC1")
    ylabel("PC2")
    return z
end

# Make a QQ-plot of z versus the standard normal distribution
function qqplot(z)
    n = length(z)
    q = quantile.(Normal(),((1:n)-0.5)/n)
    plot(q,q,"k--")
    plot(q,sort(z),".")
    xlabel("Normal")
    ylabel("Observed")
    title("Q-Q plot")
end

# Compute RPM, RPKM, and TPM from a count matrix C (features-by-samples).
# This assumes that lengths[i] is the length of feature i in bases.
function standard_normalizations(C,lengths)
    S = sum(C,dims=1)/1e6
    RPM = C./S  # "reads per million"
    RPKM = RPM./(lengths/1000.0)
    TPM = RPKM ./ (sum(RPKM,dims=1)/1e6)
    # RPK = C./(lengths/1000.0)
    # TPM = RPK ./ (sum(RPK,dims=1)/1e6)
    return RPM, RPKM, TPM
end

# Recode a list of arbitrary labels as numbers
function recode_as_numbers(labels)
    u = unique(labels)
    K = length(u)
    D = Dict(zip(u,1:K))
    return [D[l] for l in labels], D
end

# Compute the "one-hot" representation corresponding to given the sequence of labels.
function one_hot(labels)
    u = unique(labels)
    K = length(u)
    D = Dict(zip(u,1:K))
    A = Int[(D[l]==k) for l in labels, k=1:K]
    return A,u
end

# Compute design matrix using the given formula and dataframe
function design_matrix(formula, dataframe)
    modelframe = ModelFrame(formula, dataframe)
    X = ModelMatrix(modelframe).m
    X[:,2:end] = scale(X[:,2:end],1)
    return X,coefnames(modelframe)
end

# Compute F1 score
function F1score(hits,actual_positives)
    A,B = hits,actual_positives
    precision = length(intersect(A,B)) / length(A)
    recall = length(intersect(A,B)) / length(B)
    F1 = 2/(1/precision + 1/recall)
    return F1,precision,recall
end

# Return vector of booleans indicating whether each element of a is in b.
function subset_in(a,b)
    x = falses(length(a))
    x[findall(in(b),a)] .= 1
    return x
end

# Compute Benjamini-Hochberg adjusted p-values
benjamini_hochberg(p) = (o = sortperm(p); m=length(p); padj = zeros(Float64,m); padj[o] = p[o].*(m./(1:m)); padj)

# Standardize rows and columns of a matrix to have mean zero and approximately constant variance
function standardize_rows_and_cols(Y)
    max_iter = 100
    tol = 1e-6
    Y_old = copy(Y)
    for iter = 1:max_iter 
        Y = scale(Y,1)
        Y = scale(Y,2)
        if (maximum(abs.(Y - Y_old)) < tol); break; end
        Y_old = copy(Y)
    end
    return Y
end


# Linear regression
#
# Perform estimation and inference for standard linear regression model:
#    y = X*beta + e
#    where e_i ~ N(0,sigma^2) for i=1,...,n.
#
# Inputs:
#   X = n-by-d design matrix
#   y = length n vector of outcomes
#
# Outputs:
#   beta_hat = length d vector of estimated coefficients
#   sigma_hat = estimated standard deviation of outcomes
#   stderr = length d vector of standard errors for entries of beta_hat
#   t = length d vector of t-statistics for entries of beta_hat
#   logp = natural log of p-value for the specified test (gt: alt>null, lt: alt<null, tt: alt!=null)
function infer_linear_regression(X,y; beta_null=zeros(size(X,2)), test="tt")
    n,d = size(X)
    @assert(n>d, "Sample size (n) must be greater than number of coefficients (d).")
    beta_hat = vec(pinv(X)*y)
    y_hat = vec(X*beta_hat)
    e = y - y_hat
    sigma_hat = sqrt.(sum(e.*e)/(n-d))
    stderr = sigma_hat .* sqrt.(diag(inv(X'*X)))
    t = (beta_hat - beta_null) ./ stderr
    logp_gt = logccdf.(TDist(n-d),t)
    logp_lt = logcdf.(TDist(n-d),t)
    logp_tt = [min(logp_gt[j],logp_lt[j])+log(2) for j=1:d]
    logp = Dict("gt"=>logp_gt, "lt"=>logp_lt, "tt"=>logp_tt)[test]
    RSS = sum(e.*e)
    TSS = sum((y .- mean(y)).^2)
    R_squared = 1 - RSS/TSS
    return beta_hat,sigma_hat,stderr,t,logp,R_squared
end




# Binary segmentation using normal model with known variances
#    theta = length n vector to hold estimated segment mean estimates (this will be modified by the algorithm)
#    y = length n vector of observations, where y[j] ~ Normal(theta[j],1/w[j]).
#    w = length n vector of precisions, w[j] = 1/variance[j].
#    gamma = real-valued penalty on the number of segments.
#    lambda =  prior precision for the mean of a segment, given that it is nonzero.
#    alpha = prior probability that a segment has nonzero mean.
function binary_segmentation!(theta,y,w,gamma; lambda=0.0, alpha=1.0, seg_start=[1])
    for s = 1:length(seg_start)
        i = seg_start[s]  # beginning of segment
        k = (s < length(seg_start) ? seg_start[s+1]-1 : length(y))  # end of segment
        binary_segmentation_recursion!(theta, y, w, gamma, lambda, alpha, sum(w[i:k]), sum(w[i:k].*y[i:k]), i, k)
    end
    return theta
end

# Recursion for binary segmentation
function binary_segmentation_recursion!(theta, y, w, gamma, lambda, alpha, N, S, i, k)
    N1 = 0.0
    S1 = 0.0
    Qmin,Jmin,Nmin,Smin = Inf,0,0.0,0.0
    for j = i:k-1
        N1 = N1 + w[j]
        S1 = S1 + w[j]*y[j]
        Q1 = -S1^2/N1 - (S-S1)^2/(N-N1)
        if Q1 < Qmin; Qmin = Q1; Jmin = j; Nmin = N1; Smin = S1; end
    end
    if Qmin + gamma < -S^2/N   # if i==k then this is false since Qmin==Inf.
        binary_segmentation_recursion!(theta,y,w,gamma,lambda,alpha,Nmin,Smin,i,Jmin)
        binary_segmentation_recursion!(theta,y,w,gamma,lambda,alpha,N-Nmin,S-Smin,Jmin+1,k)
    else
        p_zero = 1/(1 + (sqrt(lambda)/sqrt(N+lambda)) * exp(0.5*S^2/(N+lambda)) * alpha/(1-alpha))
        m = (p_zero > 0.5 ? 0.0 : S/(N+lambda))
        for j = i:k; theta[j] = m; end
    end
end






