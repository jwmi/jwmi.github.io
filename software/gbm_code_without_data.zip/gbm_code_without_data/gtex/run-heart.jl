# Analyze RNA-seq data from GTEx
# Test for genes that are associated with aging in the "Heart - Left Ventricle" samples.
#
# Author: Jeffrey W. Miller
# Date: Oct 10, 2020


# _________________________________________________________________________________________________
# Load functions

using RData
using CSV
using DataFrames
using CategoricalArrays
using DelimitedFiles
using Random
include("../splines.jl")
include("../helper.jl")
include("../gbm.jl")

rc("font", family="Georgia")


# _________________________________________________________________________________________________
# Load data

Y = load("data-heart.rda")["counts"]
gene_info = CSV.read("gene_info-heart.txt"; delim='\t')
sample_info = CSV.read("sample_info-heart.txt"; delim='\t')
I,J = size(Y)

@assert(all(sample_info[!,:passed_qc].==1))
@assert(all(sample_info[!,:smtsd].=="Heart - Left Ventricle"))


# _________________________________________________________________________________________________
# Model definition

# Construct gene-specific design matrix
println("Constructing gene-specific design matrix...")
X_loglength = log.(gene_info[!,:seq_len])
X_gc = [gene_info[!,:pct_gc]  moment2(gene_info[!,:pct_gc])]
X = [ones(I) X_loglength X_gc]
X[:,2:end] = scale(X[:,2:end],1)

# Construct sample-specific design matrix
println("Constructing sample-specific design matrix...")
Z,Znames = design_matrix(@formula(sampid ~ 1 + age_numeric + smexncrt), sample_info)



# _________________________________________________________________________________________________
# Test for age-associated genes using the GBM

Random.seed!(0)
M = 3  # number of latent factors to use  (M=3 was indicated for "Heart - Left Ventricle" on the exploratory data)
results_dir = "results_heart"
gene_of_interest = "PCMT1"  # this is the top hit for M=3 on the Left Ventricle data
if !isdir(results_dir); mkdir(results_dir); end


println("Estimating parameters...")
A,B,C,D,U,V,S,T,omega,logp_r = gbm_estimation(Y,X,Z,M; verbose=true)
        
println("Inferring standard errors...")
se_A,se_B,se_C,se_D,se_U,se_V,se_S,se_T = gbm_inference(Y,X,Z,A,B,C,D,U,V,S,T,omega)

println("Testing for association with age...")
l_age = findfirst([split(name,":")[1] for name in Znames].=="age_numeric")
zscores = B[:,l_age] ./ se_B[:,l_age]
p = 2*ccdf.(Normal(0,1), abs.(zscores))
hits = sortperm(p)
hits = hits[p[hits] .< 0.05/length(p)]

println("Save/report results...")
i_gene = findfirst(gene_info[!,:symbol] .== gene_of_interest)
gene_info[!,:gene_id_noversion] = [split(id,".")[1] for id in gene_info[!,:gene_id]]
writedlm(results_dir*"/hits.txt",gene_info[hits,:gene_id_noversion])
writedlm(results_dir*"/background_list.txt",gene_info[!,:gene_id_noversion])  # Background list of genes (for enrichment analysis)
results = DataFrame(gene_id=gene_info[hits,:gene_id], symbol=gene_info[hits,:symbol], pvalue=p[hits])
CSV.write(results_dir*"/results.txt", results; delim='\t')

# Compute GBM residuals
rx = [1]        # retain these X covariates in residuals (do not adjust them out)
rz = [1,l_age]  # retain these Z covariates in residuals (do not adjust them out)
Res = adjusted_residuals(Y,X,Z,A,B,C,D,U,V; rx=rx, rz=rz)

# Compute standard normalizations for comparison
RPM, RPKM, TPM = standard_normalizations(Y, gene_info[!,:seq_len])


function test_association(x,Y)
    I,J = size(Y)
    logpvalues = zeros(I)
    for i = 1:I
        beta_hat,sigma_hat,stderr,t,logp,R_squared = infer_linear_regression([ones(J) x], Y[i,:]; beta_null=zeros(2), test="tt")
        logpvalues[i] = logp[2]
    end
    return logpvalues
end

function plot_association(x,y,xs,xs_names; showline=false)
    Random.seed!(0)
    J = length(x)
    jitter = (rand(J) .- 0.5)*3
    plot(x .+ jitter, y, "b.", ms=3)
    if showline
        beta_hat,sigma_hat,stderr,t,logp,R_squared = infer_linear_regression([ones(J) x], y; beta_null=zeros(2), test="tt")
        plot(xs, [ones(length(xs)) xs]*beta_hat, "k-", lw=1)
    end
    grid(linewidth=0.25)
    xticks(xs,xs_names)
end

x = sample_info[!,:age_numeric]
xs = sort(unique(sample_info[!,:age_numeric]))
xs_names = sort(unique(sample_info[!,:age]))

# Plot estimated expression versus age for top hit, using GBM residuals
figure(1, figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
plot_association(x,Res[i_gene,:],xs,xs_names; showline=true)
title("$gene_of_interest versus age (GBM)")
xlabel("age")
ylabel("estimated expression")
savefig(results_dir*"/$(gene_of_interest)_vs_age-GBM.png"; dpi=200)

# Plot estimated expression versus age for top hit, using scaled counts
figure(2, figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
plot_association(x,log.(Y[i_gene,:].+1),xs,xs_names)
title("$gene_of_interest versus age (log counts)")
xlabel("age")
ylabel("estimated expression")
savefig(results_dir*"/$(gene_of_interest)_vs_age-scaled_counts.png"; dpi=200)

# Plot estimated expression versus age for top hit, using log TPMs
figure(3, figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
plot_association(x,log.(TPM[i_gene,:].+1),xs,xs_names)
title("$gene_of_interest versus age (log TPMs)")
xlabel("age")
ylabel("estimated expression")
savefig(results_dir*"/$(gene_of_interest)_vs_age-logTPMs.png"; dpi=200)


println("Bonferroni threshold  = ",0.05/I)
println("(GBM model-based)    p-value for $gene_of_interest     = ",p[i_gene])
println("(GBM model-based)    # significant         = ",sum(p .< 0.05/I))
println()

# Compare with using estimated expression based on GBM residuals
logpvalues = test_association(x,Res)
println("(GBM-adj log-counts) p-value for $gene_of_interest     = ",exp(logpvalues[i_gene]))
println("(GBM-adj log-counts) # significant         = ",sum(logpvalues .< log(0.05/I)))
println()

# Compare with using log of scaled counts
logpvalues = test_association(x,log.(Y.+1))
println("(log of scaled counts) p-value for $gene_of_interest   = ",exp(logpvalues[i_gene]))
println("(log of scaled counts) smallest p-value    = ",exp(minimum(logpvalues)))
println("(log of scaled counts) # significant       = ",sum(logpvalues .< log(0.05/I)))
println()

# Compare with using log of TPMs
logpvalues = test_association(x,log.(TPM.+1))
println("(log of TPMs) p-value for $gene_of_interest            = ",exp(logpvalues[i_gene]))
println("(log of TPMs) smallest p-value             = ",exp(minimum(logpvalues)))
println("(log of TPMs) # significant                = ",sum(logpvalues .< log(0.05/I)))
println()
logpvalues = test_association(x,log.(RPKM.+1))
println("(log of RPKMs) p-value for $gene_of_interest           = ",exp(logpvalues[i_gene]))
println("(log of RPKMs) smallest p-value            = ",exp(minimum(logpvalues)))
println("(log of RPKMs) # significant               = ",sum(logpvalues .< log(0.05/I)))
println()



















