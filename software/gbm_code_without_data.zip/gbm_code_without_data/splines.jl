# Compute B-spline basis
#
# Author: Jeffrey W. Miller
# Date: April 6, 2019
#
# References:
# - "B-splines and divided differences", James D Emery, 2009.  http://www.stem2.org/je/bspline.pdf  (Note typo in formula for derivs on p.14; see v below.)
# - "Derivative of B-spline function", http://mat.fsv.cvut.cz/gcg/sbornik/prochazkova.pdf
# (For computing the natural spline basis:)
# - "Generalized Additive Models", Hastie and Tibshirani, 1990, CRC Press.  (See page 36, exercise 2.5.) 
# - R source code for splines library: src/library/splines/R/splines.R and src/library/splines/R/splineClasses.R


using LinearAlgebra


# Compute B-spline basis
# (Comparable to the bs and ns functions in the R splines library.)
#
# x = points at which to evaluate basis functions
# K = number of internal knots
# degree = degree of polynomials
# knots = internal knots (if specified, then this overrides K)
# percentiles = percentiles to use for internal knots (if specified, then this overrides K and knots)
# lb,ub = lower and upper boundary knots
# natural = use natural splines or not
# intercept = include intercept in the basis or not
function bspline(x, K=3; degree=3, knots=uquant(x,K), percentiles=Float64[], lb=minimum(x), ub=maximum(x), natural=false, intercept=false)
    if !isempty(percentiles); knots = quantile(x,percentiles); end
    K = length(knots)
    order = degree+1
    augknots = sort([knots; lb; ub; repeat([lb-eps(),ub+eps()],order-1)])
    B,D,H = bspline_core(x,augknots,order)
    keep = (1 + !intercept):(K+order)
    B = B[keep,:]
    D = D[keep,:]
    H = H[keep,:]
    
    if natural
        QR = qr(H[:,[1,end]])
        basis = (B'*QR.Q)[:,3:end]
        # Q = qr(H[:,[1,end]],thin=false)[1]
        # basis = (B'*Q)[:,3:end]
    else
        basis = B'
    end
    return basis,knots
end


# Low-level function for B-spline recursion.
# (Comparable to the splineDesign function in the R splines library.)
#
# x = points at which to evaluate basis functions
# augknots = augmented knot sequence
# order = order of B-spline
function bspline_core(x,augknots,order=4)
    n = length(x)
    m = length(augknots)-1
    t = sort(augknots)
    B = [float(t[i] <= x[j] < t[i+1]) for i=1:m, j=1:n]
    D = zeros(m,n)  # first derivatives
    H = zeros(m,n)  # second derivatives
    for k = 2:order
        for j = 1:n
            for i = 1:m-k+1
                dt = t[i+k-1] - t[i]; u = (dt>0 ? 1/dt : 0.0)
                dt = t[i+k] - t[i+1]; v = (dt>0 ? 1/dt : 0.0)
                if k==order; H[i,j] = (k-1)*(D[i,j]*u - D[i+1,j]*v); end
                if k>=order-1; D[i,j] = (k-1)*(B[i,j]*u - B[i+1,j]*v); end
                B[i,j] = B[i,j]*(x[j] - t[i])*u + B[i+1,j]*(t[i+k] - x[j])*v
            end
        end
    end
    return B,D,H
end


# Compute K uniformly spaced quantiles of x
uquant(x,K) = quantile(x,(1:K)/(K+1))


# Compute natural B-spline basis
nspline(x, K=3; kwargs...) = bspline(x,K; natural=true, kwargs...)

















