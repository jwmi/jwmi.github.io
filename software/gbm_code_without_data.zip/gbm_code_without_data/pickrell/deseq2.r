# DESeq2 analysis for comparison

# Installing DESeq2 and associated packages:
# > if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
# > BiocManager::install("DESeq2")
# > BiocManager::install("apeglm")
# > BiocManager::install("limma")
# > BiocManager::install("cqn")

# _________________________________________________________________________________________________
# Load stuff

# Load libraries
library(cqn)
library(DESeq2)
library(apeglm)

# Load data and covariate info
Y = as.matrix(read.table("data.txt", header=F, sep="\t"))
gene_info = read.table("gene_info.txt", header=T, sep="\t")
sample_info = read.table("sample_info.txt", header=T, sep="\t")

# Exclude genes with median count of 0
genes_to_use = (rowMedians(Y) > 0)
Y = Y[genes_to_use,]
gene_info = gene_info[genes_to_use,]

I = nrow(Y)
J = ncol(Y)

sample_info$center = as.factor(sample_info$center)
sample_info$lane = as.factor(sample_info$lane)





# _________________________________________________________________________________________________
# Run CQN to handle GC bias

start_time = Sys.time()

cqn_output = cqn(Y, lengths=gene_info$len, x=gene_info$gc_content, verbose=T)
cqnNormFactors = exp(cqn_output$glm.offset)
normFactors = cqnNormFactors / exp(rowMeans(log(cqnNormFactors)))


# _________________________________________________________________________________________________
# Run DESeq2 on full dataset

gc_adjust = TRUE

dds = DESeqDataSetFromMatrix(countData = Y,
                             colData = sample_info,
                             design = ~ center + concentration)
# Use CQN to set the normalization factors to use in DESeq2
if (gc_adjust) { normalizationFactors(dds) = normFactors }
dds = DESeq(dds)

end_time = Sys.time()
end_time - start_time

resultsNames(dds)
res = results(dds, name="center_yale_vs_argonne")
z = res$log2FoldChange / res$lfcSE
fname = sprintf("results/deseq2-zscores-center-gc=%s.txt",gc_adjust)
write.table(z,file=fname,col.names=F,row.names=F,sep="\t")



# _________________________________________________________________________________________________
# PCA using DESeq2's recommended approach with VST

# PCA plot
vsd = vst(dds)
mat = assay(vsd)
mat = limma::removeBatchEffect(mat, batch=vsd$center, covariates=vsd$concentration)
assay(vsd) = mat
pc = plotPCA(vsd, intgroup="subject_id", returnData=T)
fname = sprintf("results/deseq2-pca-gc=%s.txt",gc_adjust)
write.table(pc[,1:3],file=fname,row.names=F,sep="\t")



# _________________________________________________________________________________________________
# Run DESeq2 on random splits

gc_adjust = TRUE

splits = as.matrix(read.table("results/splits-pickrell-nreps=50-subset=all.tsv", header=F, sep="\t"))

nreps = ncol(splits)

zscores = matrix(0,I,nreps)
for (r in 1:nreps) {
    print(r)
    sample_info$condition = splits[,r]
    sample_info$condition = as.factor(sample_info$condition)
    
    dds = DESeqDataSetFromMatrix(countData = Y,
                                 colData = sample_info,
                                 design = ~ center + concentration + condition)
    # Use CQN to set the normalization factors to use in DESeq2
    if (gc_adjust) { normalizationFactors(dds) = normFactors }
    dds = DESeq(dds)
    res = results(dds, name="condition_1_vs_0")
    z = res$log2FoldChange / res$lfcSE
    # p = res$pvalue
    
    zscores[,r] = z
}
fname = sprintf("results/deseq2-zscores-random-splits-gc=%s.txt",gc_adjust)
write.table(zscores,file=fname,col.names=F,row.names=F,sep="\t")































