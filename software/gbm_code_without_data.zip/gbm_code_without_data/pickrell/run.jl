# Analyze RNA-seq data from Pickrell et al. (2010)
#
# Author: Jeffrey W. Miller
# Date: Oct 10, 2020


# _________________________________________________________________________________________________
# Load functions

using CSV
using DataFrames
using CategoricalArrays
using DelimitedFiles
using Random
include("../splines.jl")
include("../helper.jl")
include("../gbm.jl")
colors_original = copy(colors)
colors = [colors; "#222222"; "#000000"]


results_dir = "results"
if !isdir(results_dir); mkdir(results_dir); end

# _________________________________________________________________________________________________
# Load data

Y = readdlm("data.txt",Int)
gene_info = CSV.read("gene_info.txt"; delim='\t')
sample_info = CSV.read("sample_info.txt"; delim='\t')

# Exclude genes with median count of 0
genes_to_use = vec(median(Y,dims=2) .> 0)
Y = Y[genes_to_use,:]
gene_info = gene_info[genes_to_use,:]

I,J = size(Y)

# yale_read_length = 35  # length of reads
# argonne_read_length = 46  # length of reads
gene_info[!,:adjusted_length] = gene_info[!,:len] .+ 40

categorical!(sample_info,:center)
categorical!(sample_info,:lane)


# _________________________________________________________________________________________________
# Model definition

# Construct gene-specific design matrix
println("Constructing gene-specific design matrix...")
knots = [0.025, 0.25, 0.5, 0.75, 0.975]
X_gc = nspline(gene_info[!,:gc_content], percentiles=knots)[1]
gc_adjust = true
if gc_adjust
    X = [ones(I) X_gc]
else
    X = ones(I,1)
end
X[:,2:end] = scale(X[:,2:end],1)

# Construct sample-specific design matrix
println("Constructing sample-specific design matrix...")
Z,Znames = design_matrix(@formula(sample_id ~ 1 + center + concentration), sample_info)

# _________________________________________________________________________________________________
# Computation time for GBM versus DESeq on full dataset
if false

M = 0  # number of latent factors to use

@time A,B,C,D,U,V,S,T,omega,logp_r = gbm_estimation(Y,X,Z,M; verbose=false);
# 35.645722 seconds (5.41 M allocations: 14.065 GiB, 5.86% gc time)

@time se_A,se_B,se_C,se_D,se_U,se_V,se_S,se_T = gbm_inference(Y,X,Z,A,B,C,D,U,V,S,T,omega);
#  6.687100 seconds (2.38 M allocations: 6.352 GiB, 13.90% gc time)

end

# _________________________________________________________________________________________________
# Compute latent factors for visualization
if true

M = 2  # number of latent factors to use

println("Estimating parameters...")
A,B,C,D,U,V,S,T,omega,logp_r = gbm_estimation(Y,X,Z,M; verbose=true)

for colorby in [:center,:concentration,:lane,:subject_id]
    figure(1, figsize=(10,7)); clf(); grid(linewidth=0.25)
    group = string.(sample_info[!,colorby])
    plotgroups(V[:,1], V[:,2], group; ms=6, mec="k", mew=0.25)
    xlabel("latent factor 1")
    ylabel("latent factor 2")
    title("GBM latent factors for Pickrell data")
    savefig(results_dir*"/latentfactors-M=$M-$colorby-gc=$(gc_adjust).png",dpi=200)
end

end


# _________________________________________________________________________________________________
# Run GBM on full dataset
if true

M = 0  # number of latent factors to use

println("Estimating parameters...")
A,B,C,D,U,V,S,T,omega,logp_r = gbm_estimation(Y,X,Z,M; verbose=true)

if true  # Differential expression between centers (using GBM)
    se_A,se_B,se_C,se_D,se_U,se_V,se_S,se_T = gbm_inference(Y,X,Z,A,B,C,D,U,V,S,T,omega)
    ind_center = 2
    zscores = B[:,ind_center] ./ se_B[:,ind_center]
    p = 2*ccdf.(Normal(0,1), abs.(zscores))
    println("Most significant p-values for DE between centers:"); display(sort(p)[1:10])
    println("(GBM)    Number of p-values significant at p < 0.05 after Bonferroni correction: ",sum(p .< 0.05/length(p)))
    
    # Compare with DESeq2 results for differential expression between centers
    zscores_deseq = readdlm(results_dir*"/deseq2-zscores-center-gc=TRUE.txt")
    p_deseq = 2*ccdf.(Normal(0,1), abs.(vec(zscores_deseq)))
    println("(DESeq2) Number of p-values significant at p < 0.05 after Bonferroni correction: ",sum(p_deseq .< 0.05/length(p_deseq)))

    # Plot CDF of p-values for differential expression between centers
    figure(2,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
    plotcdf(p; log=true, ls="-", lw=1, label="GBM")
    plotcdf(p_deseq; log=true, ls="--", lw=1, label="DESeq2")
    title("P-value CDF between centers")
    ylabel("CDF")
    xlabel("p-value")
    xticks(10.0.^(-300:50:0))
    xlim(1e-175,1/length(p))
    ylim(0,0.055)
    legend(loc="upper left")
    grid(linewidth=0.25)
    savefig(results_dir*"/pvalue_cdfs-pickrell-center-M=$M-logscale.png",dpi=200)
end
# (GBM)    Number of p-values significant at p < 0.05 after Bonferroni correction: 1038
# (DESeq2) Number of p-values significant at p < 0.05 after Bonferroni correction: 892


# Compare with TPMs
RPM, RPKM, TPM = standard_normalizations(Y, gene_info[!,:adjusted_length])
Ytpm = log.(TPM.+1)
# PCA of TPMs
figure(1, figsize=(10,7)); clf(); grid(linewidth=0.25)
group = group = string.(sample_info[!,:subject_id])
pc = pcaplot(Ytpm, group; ms=6, mec="k", mew=0.25)
# for j = 1:J; text(pc[1,j]+2,pc[2,j],j); end
title("PCA of TPMs for Pickrell data")
savefig(results_dir*"/pca-TPMs-subject_id.png",dpi=200)


# Compare with DESeq2
figure(1, figsize=(10,7)); clf(); grid(linewidth=0.25)
pc_deseq = CSV.read(results_dir*"/deseq2-pca-gc=TRUE.txt"; delim='\t')
plotgroups(pc_deseq[!,:PC1],pc_deseq[!,:PC2],pc_deseq[!,:group]; ms=6, mec="k", mew=0.25)
xlabel("PC1")
ylabel("PC2")
title("PCA of DESeq2 transformation of Pickrell data")
savefig(results_dir*"/pca-deseq2-subject_id-gc=true.png",dpi=200)


end

# _________________________________________________________________________________________________
# Run GBM on random splits
if true

nreps = 50 # 50  # number of replicates to run
Ms = [0]  # values of M to use (number of latent factors)
# subsets = ["all","yale","argonne","love14"]
subsets = ["all"]

if true  # Generate results files
    for subset in subsets
        if subset=="all"
            Zs_ = design_matrix(@formula(sample_id ~ 1 + center + concentration), sample_info)[1]
            Ys = Y
        elseif subset=="love14"
            inds = findall(sample_info[!,:used_in_love14].==1)
            Zs_ = design_matrix(@formula(sample_id ~ 1 + concentration), sample_info[inds,:])[1]
            Ys = Y[:,inds]
        else
            inds = findall(sample_info[!,:center].==subset)
            Zs_ = design_matrix(@formula(sample_id ~ 1 + concentration), sample_info[inds,:])[1]
            Ys = Y[:,inds]
        end
        Js = size(Ys,2)
        splits = zeros(Int,Js,nreps)
        
        for M in Ms
            zscores = zeros(I,nreps)
            for rep in 1:nreps
                println("____________ (Calibration on random splits) subset = $subset, M = $M, rep = $rep of $nreps ____________")
                Random.seed!(rep)
                
                S1 = randperm(Js)[1:round(Int,Js/2)]
                splits[:,rep] .= 0
                splits[S1,rep] .= 1
                
                # Add fake condition to sample design matrix
                Zs = [Zs_ splits[:,rep]]
                Zs[:,end] = scale(Zs[:,end])
                
                A,B,C,D,U,V,S,T,omega,logp_r = gbm_estimation(Ys,X,Zs,M; verbose=true)
                se_A,se_B,se_C,se_D,se_U,se_V,se_S,se_T = gbm_inference(Ys,X,Zs,A,B,C,D,U,V,S,T,omega)

                zscores[:,rep] = B[:,end]./se_B[:,end]
            end
            
            writedlm(results_dir*"/zscores-pickrell-nreps=$nreps-subset=$subset-M=$M.tsv", zscores)
        end
		writedlm(results_dir*"/splits-pickrell-nreps=$nreps-subset=$subset.tsv", splits)
    end
end


# Plot p-value CDFs
for M in Ms
    figure(2,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
    for subset in subsets
        zscores = readdlm(results_dir*"/zscores-pickrell-nreps=$nreps-subset=$subset-M=$M.tsv")
        p = 2*ccdf.(Normal(0,1), abs.(vec(zscores)))
        plot(sort(p), ((1:length(p)) .- 0.5)/length(p), "-", lw=1, label=subset)
    end
    plot([0,1],[0,1],"k-",lw=0.25)
    title("P-value CDF across random splits (M = $M)")
    ylabel("CDF")
    xlabel("p-value")
    grid(linewidth=0.25)
    xlim(0,0.1); ylim(0,0.1)
    legend()
    savefig(results_dir*"/pvalue_cdfs-pickrell-random-nreps=$nreps-M=$M.png",dpi=200)
    xlim(0,1); ylim(0,1)
    savefig(results_dir*"/pvalue_cdfs-pickrell-random-nreps=$nreps-M=$M-axis01.png",dpi=200)
end

end

# Compare with DESeq2 results on random splits
if false
    zscores = readdlm(results_dir*"/zscores-pickrell-nreps=$nreps-subset=all-M=0.tsv")
    zscores_deseq = readdlm(results_dir*"/deseq2-zscores-random-splits-gc=TRUE.txt")
    
    figure(2,figsize=(4,3.5)); clf(); subplots_adjust(left=0.2,bottom=0.2,right=0.85)
    p = 2*ccdf.(Normal(0,1), abs.(vec(zscores)))
    p_deseq = 2*ccdf.(Normal(0,1), abs.(vec(zscores_deseq)))
    plot(sort(p), ((1:length(p)) .- 0.5)/length(p), "-", lw=1, label="GBM")
    plot(sort(p_deseq), ((1:length(p_deseq)) .- 0.5)/length(p_deseq), "--", lw=1, label="DESeq2")
    plot([0,1],[0,1],"k-",lw=0.25)
    title("P-value CDF across random splits")
    ylabel("CDF")
    xlabel("p-value")
    grid(linewidth=0.25)
    xlim(0,0.1); ylim(0,0.1)
    legend()
    savefig(results_dir*"/pvalue_cdfs-pickrell-random-nreps=$nreps-GBM-vs-DESeq2.png",dpi=200)
    xlim(0,1); ylim(0,1)
    savefig(results_dir*"/pvalue_cdfs-pickrell-random-nreps=$nreps-GBM-vs-DESeq2-axis01.png",dpi=200)
end










