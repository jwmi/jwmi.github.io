# Estimation and inference for Negative-Binomial generalized bilinear model (NB-GBM) with log(E(Y)) = XA' + BZ' + XCZ' + UDV'.
#
# Author: Jeffrey W. Miller
# Date: Oct 10, 2020


# _________________________________________________________________________________________________
# General functions

using SpecialFunctions
import LinearAlgebra
Identity = LinearAlgebra.I
using TSVD


nchoose2(n) = div(n*(n-1),2)
block(i,K) = ((i-1)*K+1):(i*K)
lgamma_(x) = logabsgamma(x)[1]
SS(A) = sum(A.*A)  # sum of squares


# Log-likelihood of the Negative-Binomial distribution with mean Mu and inverse-dispersion r, on data Y.
function loglikelihood(Y,Mu,r)
    I,J = size(Y)
    ll = 0.0
    for i = 1:I
        for j = 1:J
            ll += lgamma_(r[i,j]+Y[i,j]) - lgamma_(r[i,j]) - lgamma_(Y[i,j]+1) - Y[i,j]*log1p(r[i,j]/Mu[i,j]) - r[i,j]*log1p(Mu[i,j]/r[i,j])
        end
    end
    return ll
end


logprior(A,lambda,mu=0.0) = sum(logpdf.(Normal(mu,1/lambda),A))


# Prior structure
#    lambda_* = precision of the Normal prior on the entries of A, B, C, D, U, V, S, or T.
#    mu_S, mu_T = means of the Normal priors on the entries of S and T, respectively, e.g., S[i] ~ Normal(mu_S, 1/lambda_S).
#    The prior mean for A, B, C, D, U, and V is zero, e.g., A[j,k] ~ N(0, 1/lambda_A).
mutable struct Prior
    lambda_A::Float64
    lambda_B::Float64
    lambda_C::Float64
    lambda_D::Float64
    lambda_U::Float64
    lambda_V::Float64
    lambda_S::Float64
    lambda_T::Float64
    mu_S::Float64
    mu_T::Float64
    Prior() = (p = new();
        p.lambda_A = p.lambda_B = p.lambda_C = p.lambda_D = p.lambda_U = p.lambda_V = 1.0;
        p.lambda_S = p.lambda_T = 1.0;
        p.mu_S = p.mu_T = 0.0;
        return p
    )
end


# Check identifiability constraints and interpretation identities
function check_constraints(Y,X,Z,A,B,C,D,U,V,S,T)
    I,M = size(U)
    @assert(maximum(abs.(X'*B)) < 1e-10)
    @assert(maximum(abs.(Z'*A)) < 1e-10)
    if M > 0
        @assert(maximum(abs.(X'*U)) < 1e-10)
        @assert(maximum(abs.(Z'*V)) < 1e-10)
        @assert(maximum(abs.(U'*U - Identity)) < 1e-8)
        @assert(maximum(abs.(V'*V - Identity)) < 1e-8)
        # @assert(all(sign.(U'*((-1).^(1:size(U,1)))).==1))
        if M > 1; @assert(maximum(diff(D)) <= 0); end
    end
    @assert(abs(mean(exp.(S)) .- 1) < 1e-10)
    @assert(abs(mean(exp.(T)) .- 1) < 1e-10)
    @assert(minimum(svdvals(X)) > 0)
    @assert(minimum(svdvals(Z)) > 0)
    logMu = X*A' + B*Z' + X*C*Z' + U*(D.*V')
    @assert(abs.(mean(logMu) - C[1,1]) < 1e-12)
    @assert(maximum(abs.(vec(mean(logMu, dims=2)) - B[:,1] - X*C[:,1])) < 1e-12)
    @assert(maximum(abs.(vec(mean(logMu, dims=1)) - A[:,1] - Z*C[1,:])) < 1e-12)
end


# Compute miscellaneous
function compute_misc(Y,X,Z,A,B,C,D,U,V,S,T,omega; Offset=0.0*Y)
    I,J = size(Y)
    
    # Compute Mu, W, E, and r
    Mu = zeros(I,J)
    W = zeros(I,J)
    E = zeros(I,J)
    logMu = X*A' + B*Z' + X*C*Z' + U*(D.*V') + Offset
    r = exp.(-(S.+T'.+omega))
    compute_MuWE!(Mu,W,E,Y,logMu,r)
    
    # Verify that the constraints are satisfied
    check_constraints(Y,X,Z,A,B,C,D,U,V,S,T)
    
    # Compute proportion of variation explained
    ss = [SS(X*A'), SS(B*Z'), SS(X*C*Z'), SS(U*(D.*V'))]
    
    return E,W,ss
end


# Compute adjusted GBM residuals
#    rx = indices of X covariates to retain in residuals (do not adjust them out)
#    rz = indices of Z covariates to retain in residuals (do not adjust them out)
#    ru = indices of latent factors to retain in residuals (do not adjust them out)
function adjusted_residuals(Y,X,Z,A,B,C,D,U,V; rx=[], rz=[], ru=[])
    logMu = X*A' + B*Z' + X*C*Z' + U*(D.*V')
    logMu_retain = X[:,rx]*A[:,rx]' + B[:,rz]*Z[:,rz]' + X[:,rx]*C[rx,rz]*Z[:,rz]' + U[:,ru]*(D[ru].*V[:,ru]')
    Residuals = log.(Y .+ 0.125) .- logMu
    return logMu_retain .+ Residuals
end



# _________________________________________________________________________________________________

# Estimate the parameters (A,B,C,D,U,V,S,T,omega) of a Negative-Binomial generalized bilinear model (NB-GBM):
#    Y_ij ~ NegativeBinomial(mean = exp(eta_ij), dispersion = exp(s_i + t_j + omega))
#    where eta = XA' + BZ' + XCZ' + UDV'
#    subject to the identifiability constraints Z'*A=0, X'*B=0, X'*U=0, Z'*V=0, U'*U=I, V'*V=I, mean(exp(S))=1, mean(exp(T))=1, and
#    D is diagonal with D_11 > D_22 > ... > D_MM > 0.  This function does not enforce a sign constraint on U and V.
#
# INPUTS (REQUIRED):
#    Y = I-by-J matrix of nonnegative integer counts, where Y[i,j] = count for feature i, sample j.
#    X = I-by-K matrix of feature covariates, where X[i,k] = value of covariate k for feature i.
#    Z = J-by-L matrix of sample covariates, where Z[j,l] = value of covariate l for sample j.
#    M (Int64) = dimension of latent factors (i.e., rank of UDV').
#
#    It is assumed that X[i,1]==1 for all i, Z[j,1]==1 for all j, and X[:,k] and Z[:,l] are zero mean, unit variance for all k>1 and l>1.
#
# INPUTS (OPTIONAL):
#    max_iterations (Int64) = maximum number of iterations to run the algorithm.
#    tolerance (Float64) = stop when the relative change in log-likelihood is less than this value or max_iterations has been reached.
#    max_step (Float64) = maximum step size for each Fisher scoring / Newton-Raphson update.
#    verbose (Bool) = print status of algorithm while running.
#    prior (Prior) = prior parameters.  (Must be a struct of type "Prior" as defined in this file.)
#    init_params (tuple) = tuple of parameters (A,B,C,D,U,V,S,T,omega) to use for initializing the algorithm.
#    Offset = I-by-J matrix of offsets to eta.
#
# OUTPUTS:
#    A = J-by-K matrix of coefficients for feature covariates
#    B = I-by-L matrix of coefficients for sample covariates
#    C = K-by-L matrix of intercepts and interaction coefficients
#    D = M-by-1 matrix of latent factor weights
#    U = I-by-M matrix of feature-wise latent factors
#    V = J-by-M matrix of sample-wise latent factors
#    S = I-by-1 matrix of feature-specific log-dispersion offsets
#    T = J-by-1 matrix of sample-specific log-dispersion offsets
#    omega = overall log-dispersion parameter
#
# DIMENSIONS OF INPUTS/OUTPUTS:
#    I = number of features
#    J = number of samples
#    K = number of feature covariates
#    L = number of sample covariates
#    M = number of latent factors
#
function gbm_estimation(Y,X,Z,M; max_iterations=50, tolerance=1e-6, max_step=5.0, verbose=true, prior=Prior(), init_params=(), Offset=0.0*Y, update_S=true, update_T=true)
    I,K = size(X)
    J,L = size(Z)
    A = zeros(J,K)
    B = zeros(I,L)
    C = zeros(K,L)
    D = zeros(M)
    U = zeros(I,M)
    V = zeros(J,M)
    S = zeros(I,1)
    T = zeros(J,1)
    omega = 0.0
    
    Mu = zeros(I,J)
    W = zeros(I,J)
    E = zeros(I,J)
    logp_old = Inf
    b_S = max_step*ones(I)
    b_T = max_step*ones(J)
    
    @assert(K > 0)
    @assert(L > 0)
    @assert(M >= 0)
    @assert(M < min(I,J))
    
    pinv_Z = pinv(Z)
    pinv_X = pinv(X)
    
    p = prior
    
    # Initialize
    if isempty(init_params)
        A,B,C = recover_parameters(log.(Y.+0.125)-Offset,X,Z,M; ABC_only=true)  # fit using only the A,B,C terms to avoid overfitting in the UDV' term
        
        U,D,V = tsvd(1e-8*randn(I,J),M)  # randomly initialize UDV' to something random and negligible (this is to avoid numerical issues due to zeros)
        Mu = exp.(X*A' + B*Z' + X*C*Z' + U*(D.*V') + Offset)
        r = exp.(-(S .+ T' .+ omega))
        for iter = 1:4
			# initialize S,T,omega using a few optimization steps
            S,T,omega,r,b_S,b_T = update_logdispersions(S,T,omega,Y,Mu,r,p,max_step,b_S,b_T,true,true,verbose)
        end
    else
        (A,B,C,D,U,V,S,T,omega) = deepcopy(init_params)
    end
    logMu = X*A' + B*Z' + X*C*Z' + U*(D.*V') + Offset
    Mu = exp.(logMu)
    r = exp.(-(S.+T'.+omega))
    
    # Record-keeping
    logp = zeros(max_iterations)
    
    # Estimate parameters
    for iteration = 1:max_iterations
        # Update A
        compute_MuWE!(Mu,W,E,Y,logMu,r)
        logMu = logMu - X*A' - X*C*Z'
        A,C = update_main_effects(A,C,X,Z,W,E,p.lambda_A,max_step,verbose)
        logMu = logMu + X*A' + X*C*Z'
        
        # Update B
        compute_MuWE!(Mu,W,E,Y,logMu,r)
        logMu = logMu - B*Z' - X*C*Z'
        B,Ct = update_main_effects(B,C',Z,X,W',E',p.lambda_B,max_step,verbose)
        C = Ct'
        logMu = logMu + B*Z' + X*C*Z'
        
        # Update C
        compute_MuWE!(Mu,W,E,Y,logMu,r)
        logMu = logMu - X*C*Z'
        C = update_interactions(C,X,Z,W,E,p.lambda_C,max_step)
        logMu = logMu + X*C*Z'
        
        if M > 0
            # Update V,D
            compute_MuWE!(Mu,W,E,Y,logMu,r)
            B,Ct,V,D,U = update_UD(B,C',V,D,U,Z,X,pinv_Z,pinv_X,W',E',p.lambda_V,max_step,verbose); C = Ct'
			# sgn = vec(sign.(U'*((-1).^(1:size(U,1))))); U = U.*sgn'; V = V.*sgn'  # Apply sign conventions to U,D,V
            logMu = X*A' + B*Z' + X*C*Z' + U*(D.*V') + Offset
            
            # Update U,D
            compute_MuWE!(Mu,W,E,Y,logMu,r)
            A,C,U,D,V = update_UD(A,C,U,D,V,X,Z,pinv_X,pinv_Z,W,E,p.lambda_U,max_step,verbose)
			# sgn = vec(sign.(U'*((-1).^(1:size(U,1))))); U = U.*sgn'; V = V.*sgn'  # Apply sign conventions to U,D,V
            logMu = X*A' + B*Z' + X*C*Z' + U*(D.*V') + Offset
            
            # Update D
            compute_MuWE!(Mu,W,E,Y,logMu,r)
            logMu = logMu - U*(D.*V')
            F_D = compute_F_D(U,V,W)
            grad_D = vec(sum((U'*E).*V',dims=2))
            delta = (F_D + Identity*p.lambda_D) \ (grad_D - p.lambda_D*D)
            D = D + delta*min(sqrt(M)*max_step/norm(delta), 1)
            o = sortperm(D; rev=true); D = D[o]; U = U[:,o]; V = V[:,o]
            logMu = logMu + U*(D.*V')
        end
        
        # Update S, T, and omega
        Mu = exp.(logMu)
        S,T,omega,r,b_S,b_T = update_logdispersions(S,T,omega,Y,Mu,r,p,max_step,b_S,b_T,update_S,update_T,verbose)
        
        # Check for obvious issues
        if any(isnan.(A)) || any(isnan.(B)) || any(isnan.(C)) || any(isnan.(D)) || any(isnan.(U)) || any(isnan.(V)) || any(isnan.(S)) || any(isnan.(T))
            @warn("NaN's detected")
        end
        if (rank(U)<M) || (rank(V)<M)
            @warn("TSVD failure leading to insufficient rank.")
        end
        
        # Check for convergence
        logprior_value = (logprior(A,p.lambda_A) + logprior(B,p.lambda_B) + logprior(C,p.lambda_C) + logprior(D,p.lambda_D) + 
            logprior(U,p.lambda_U) + logprior(V,p.lambda_V) +  logprior(S,p.lambda_S,p.mu_S) + logprior(T,p.lambda_T,p.mu_T))
        logp_new = loglikelihood(Y,Mu,r) + logprior_value
        if verbose; println("iteration $iteration: logp = ",logp_new); end
        if (abs(logp_old/logp_new - 1) < tolerance); break; end
        logp_old = logp_new
        logp[iteration] = logp_new
        
        if (iteration==max_iterations); @warn("Maximum number of iterations reached. Possible nonconvergence."); end
    end
    
    # Softmax bias correction for S and T
    min_S,min_T = -4.0,-4.0
    S = min_S .+ log.(exp.(S .- min_S) .+ 1)
    shift = log(mean(exp.(S)))
    S = S .- shift
    omega = omega + shift
    T = min_T .+ log.(exp.(T .- min_T) .+ 1)
    shift = log(mean(exp.(T)))
    T = T .- shift
    omega = omega + shift
	
    return A,B,C,D,U,V,S,T,omega,logp
end


# _________________________________________________________________________________________________

# Compute standard errors for estimates of the parameters (A,B,C,D,U,V,S,T,omega) of a Negative-Binomial generalized bilinear model (NB-GBM).
#
# INPUTS (REQUIRED):
#    Y, X, Z, A, B, C, D, U, V, S, T, and omega (see gbm_estimation header for detail).
# 
# INPUTS (OPTIONAL):
#    prior (Prior) = prior parameters.  (Must be a struct of type "Prior" as defined in this file.)
#    Offset = I-by-J matrix of offsets to eta.
#    full_Fisher (Bool) = compute standard errors by inverting the full constraint-augmented Fisher information matrix (default = false).
#
# OUTPUTS:
#    se_A = J-by-K matrix of (approximate) standard errors for A estimates
#    se_B = I-by-L matrix of (approximate) standard errors for B estimates
#    se_C = K-by-L matrix of (approximate) standard errors for C estimates
#    se_D = M-by-1 vector of (approximate) standard errors for D estimates - TEMPORARY PLACEHOLDER - NOT EXPECTED TO GIVE REASONABLE STANDARD ERRORS FOR D
#    se_U = I-by-M matrix of (approximate) standard errors for U estimates
#    se_V = J-by-M matrix of (approximate) standard errors for V estimates
#    se_S = I-by-1 matrix of (approximate) standard errors for S estimates
#    se_T = J-by-1 matrix of (approximate) standard errors for T estimates
#
function gbm_inference(Y,X,Z,A,B,C,D,U,V,S,T,omega; prior=Prior(), Offset=0.0*Y, full_Fisher=false)
    I,K = size(X)
    J,L = size(Z)
    M = length(D)
    
    p = prior
                
    Mu = zeros(I,J)
    W = zeros(I,J)
    E = zeros(I,J)
    logMu = X*A' + B*Z' + X*C*Z' + U*(D.*V') + Offset
    r = exp.(-(S.+T'.+omega))
    compute_MuWE!(Mu,W,E,Y,logMu,r)
    
    # Compute Fisher information matrices
    F_A = [X'*(W[:,j].*X) for j=1:J]
    F_A_inv = [inv(F_A[j] + p.lambda_A*Identity) for j=1:J]
    
    F_B = [Z'*(W[i,:].*Z) for i=1:I]
    F_B_inv = [inv(F_B[i] + p.lambda_B*Identity) for i=1:I]
    
    F_C = hvcat(L, permutedims([X'*((W*(Z[:,l1].*Z[:,l2])).*X) for l1=1:L, l2=1:L])...)
    F_C_inv = inv(F_C + p.lambda_C*Identity)
    
    UD = U.*D'
    VD = V.*D'
    F_U = [VD'*(W[i,:].*VD) for i=1:I]
    F_V = [UD'*(W[:,j].*UD) for j=1:J]
    F_D = compute_F_D(U,V,W)
    F_U_inv = [inv(F_U[i] + p.lambda_U*Identity) for i=1:I]
    F_V_inv = [inv(F_V[j] + p.lambda_V*Identity) for j=1:J]
    F_D_inv = inv(F_D + p.lambda_D*Identity)
    
    if !full_Fisher
        # Compute full matrix for (U,V,Q) only, and propagate uncertainty to A,B,C.
        
        # Uncertainty in U and V
        F_U_by_V = zeros(I*M,J*M)
        for i = 1:I, j = 1:J
            for m1 = 1:M, m2 = 1:M
                F_U_by_V[(i-1)*M+m1, (j-1)*M+m2] = W[i,j]*V[j,m1]*D[m1]*U[i,m2]*D[m2]
            end
        end
        
        Q_U,Q_V = compute_constraint_Jacobian_UV(X,Z,U,V)
        
        F_UiQ = zeros(size(Q_U))
        for i = 1:I
            F_UiQ[block(i,M),:] = F_U_inv[i]*view(Q_U,block(i,M),:)
        end
        F_VUUiQ = F_U_by_V'*F_UiQ
        inv_QFUQ = inv(Q_U'*F_UiQ)
        F_UiUV = zeros(I*M,J*M)
        for i = 1:I
            F_UiUV[block(i,M),:] = F_U_inv[i]*view(F_U_by_V,block(i,M),:)
        end
        F_VUUiUV = F_U_by_V'*F_UiUV
        Temp = -F_VUUiUV + F_VUUiQ * inv_QFUQ * F_VUUiQ'
        for j=1:J; Temp[block(j,M),block(j,M)] += F_V[j] + p.lambda_V*Identity; end
        
        C_V = inv([Temp  Q_V ; Q_V' zeros(size(Q_V,2),size(Q_V,2))])[1:J*M,1:J*M]
        
        diag_T = vcat(map(diag,F_U_inv)...) - vec(sum(F_UiQ'.*(inv_QFUQ * F_UiQ'), dims=1))
        F_UVT = F_UiUV' - F_VUUiQ * inv_QFUQ * F_UiQ'
        var_U_approx = diag_T + vec(sum(F_UVT.*(C_V*F_UVT),dims=1))
        var_V_approx = diag(C_V)
        
        # Propagate uncertainty in U and V through to D
        var_D_approx = diag(F_D_inv)  # THIS IS A TEMPORARY PLACEHOLDER -- NOT EXPECTED TO GIVE REASONABLE STANDARD ERRORS FOR D
        
        # Propagate uncertainty in U and V through to A and B
        grad_A = E'*X
        grad_B = E*Z
        dW_dMu_Mu = Mu.*(r./(r.+Mu)).^2
        dE_dMu_Mu = -Mu.*r.*(r.+Y)./(r.+Mu).^2
        var_B_from_U = compute_var_B_from_U(Z,V,D,var_U_approx,F_B_inv,grad_B,dW_dMu_Mu,dE_dMu_Mu)
        var_B_from_V = compute_var_B_from_V(Z,U,D,var_V_approx,F_B_inv,grad_B,dW_dMu_Mu,dE_dMu_Mu)
        var_A_from_V = compute_var_A_from_V(X,U,D,var_V_approx,F_A_inv,grad_A,dW_dMu_Mu,dE_dMu_Mu)
        var_A_from_U = compute_var_A_from_U(X,V,D,var_U_approx,F_A_inv,grad_A,dW_dMu_Mu,dE_dMu_Mu)
        var_A_approx = vcat(map(diag,F_A_inv)...) + var_A_from_U + var_A_from_V
        var_B_approx = vcat(map(diag,F_B_inv)...) + var_B_from_U + var_B_from_V
        
        # Propagate uncertainty in A and B through to C
        grad_C = vec(X'*E*Z)
        var_C_from_A = compute_var_C_from_A(X,Z,F_A_inv,F_C_inv,grad_C,dW_dMu_Mu,dE_dMu_Mu)
        var_C_from_B = compute_var_C_from_B(X,Z,F_B_inv,F_C_inv,grad_C,dW_dMu_Mu,dE_dMu_Mu)
        var_C_approx = diag(F_C_inv) + var_C_from_A + var_C_from_B
		
    else
        # Compute the full Fisher information matrix (only used for testing purposes)
		
        F_A_full = zeros(J*K,J*K); for j = 1:J; F_A_full[block(j,K),block(j,K)] = F_A[j]; end
        F_B_full = zeros(I*L,I*L); for i = 1:I; F_B_full[block(i,L),block(i,L)] = F_B[i]; end
        F_C_full = F_C
        
        F_U_full = zeros(I*M,I*M); for i = 1:I; F_U_full[block(i,M),block(i,M)] = F_U[i]; end
        F_V_full = zeros(J*M,J*M); for j = 1:J; F_V_full[block(j,M),block(j,M)] = F_V[j]; end
        F_D_full = F_D

        F_A_by_B = hvcat(I, permutedims([W[i,j]*X[i,:]*Z[j,:]' for j=1:J, i=1:I])...)
        F_A_by_C = hvcat(L, permutedims([Z[j,l]*X'*(W[:,j].*X) for j=1:J, l=1:L])...)
        F_A_by_U = hvcat(I, permutedims([W[i,j]*X[i,:]*(V[j,:].*D)' for j=1:J, i=1:I])...)
        F_A_by_V = hvcat(J, permutedims([X'*(W[:,j1].*U.*D')*(j1==j2) for j1=1:J, j2=1:J])...)
        F_A_by_D = vcat([X'*(W[:,j].*U.*V[j,:]') for j=1:J]...)
        
        F_B_by_C = hvcat(L, permutedims([(Z'*(W[i,:].*Z[:,l]))*X[i,:]' for i=1:I, l=1:L])...)
        F_B_by_U = hvcat(I, permutedims([Z'*(W[i1,:].*V.*D')*(i1==i2)  for i1=1:I, i2=1:I])...)
        F_B_by_V = hvcat(J, permutedims([W[i,j]*Z[j,:]*(U[i,:].*D)'   for i=1:I, j=1:J])...)
        F_B_by_D = vcat([Z'*(W[i,:].*V.*U[i,:]') for i=1:I]...)
        
        F_C_by_U = hvcat(I, permutedims([X[i,:]*((W[i,:].*Z[:,l])'*(V.*D'))  for l=1:L, i=1:I])...)
        F_C_by_V = hvcat(J, permutedims([X'*(W[:,j].*Z[j,l].*U.*D') for l=1:L, j=1:J])...)
        F_C_by_D = hvcat(M, permutedims([(X.*U[:,m])'*W*(Z[:,l].*V[:,m]) for l=1:L, m=1:M])...)
        
        F_U_by_V = hvcat(J, permutedims([W[i,j]*(V[j,:].*D)*(U[i,:].*D)' for i=1:I, j=1:J])...)
        F_U_by_D = vcat([(V.*D')'*(W[i,:].*V.*U[i,:]') for i=1:I]...)
        F_V_by_D = vcat([(U.*D')'*(W[:,j].*U.*V[j,:]') for j=1:J]...)
        
        Q,Q_A,Q_B,Q_U,Q_V = compute_constraint_Jacobian(X,Z,A,B,U,V)
        
        F_ABC = [F_A_full  F_A_by_B  F_A_by_C
                 F_A_by_B' F_B_full  F_B_by_C
                 F_A_by_C' F_B_by_C' F_C_full]
        F_UVD = [F_U_full  F_U_by_V  F_U_by_D
                 F_U_by_V' F_V_full  F_V_by_D
                 F_U_by_D' F_V_by_D' F_D_full]
        F_ABC_by_UVD = [F_A_by_U F_A_by_V F_A_by_D
                        F_B_by_U F_B_by_V F_B_by_D
                        F_C_by_U F_C_by_V F_C_by_D]
        F_ABCUDV = [F_ABC         F_ABC_by_UVD 
                    F_ABC_by_UVD' F_UVD       ]
        N = size(Q,2)
        F_full = [F_ABCUDV  Q
                  Q'        zeros(N,N)]
        F_full_inv = inv(F_full)
        
        S_A = 1:J*K
        S_B = (1:I*L).+maximum(S_A)
        S_C = (1:K*L).+maximum(S_B)
        S_U = (1:I*M).+maximum(S_C)
        S_V = (1:J*M).+maximum(S_U)
        S_D = (1:M).+maximum(S_V)
        S_Q = (1:N).+maximum(S_D)
        
        var_A_approx = diag(F_full_inv)[S_A]
        var_B_approx = diag(F_full_inv)[S_B]
        var_C_approx = diag(F_full_inv)[S_C]
        var_U_approx = diag(F_full_inv)[S_U]
        var_V_approx = diag(F_full_inv)[S_V]
        var_D_approx = diag(F_full_inv)[S_D]
        
    end
    
    se_A = sqrt.(max.(eps(0.0),reshape(var_A_approx, K,J))')
    se_B = sqrt.(max.(eps(0.0),reshape(var_B_approx, L,I))')
    se_C = sqrt.(max.(eps(0.0),reshape(var_C_approx, K,L)))
    se_U = sqrt.(max.(eps(0.0),reshape(var_U_approx, M,I))')
    se_V = sqrt.(max.(eps(0.0),reshape(var_V_approx, M,J))')
    se_D = sqrt.(max.(eps(0.0),var_D_approx))
    
    # Delta propagation for S and T
    D1,D2 = compute_logdispersion_derivatives(Y,Mu,r)
    g_S = vec(sum(D1; dims=2)) .- p.lambda_S*(S .- p.mu_S)
    g_T = vec(sum(D1; dims=1)) .- p.lambda_T*(T .- p.mu_T)
    h_S = vec(sum(D2; dims=2)) .- p.lambda_S
    h_T = vec(sum(D2; dims=1)) .- p.lambda_T
    
    # Compute observed information for S and T (use observed information since expected info can't be analytically computed)
    F_S = [(h_S[i]<=0 ? -h_S[i] : NaN) for i = 1:I]
    F_T = [(h_T[j]<=0 ? -h_T[j] : NaN) for j = 1:J]
    
    var_S_from_U,var_S_from_V = compute_var_S_from_UV(Y,Mu,W,E,r,U,V,D,g_S,h_S,se_U,se_V)
    var_S_from_B,var_S_from_A = compute_var_S_from_UV(Y,Mu,W,E,r,X,Z,1,g_S,h_S,se_B,se_A)
    var_T_from_U,var_T_from_V = compute_var_T_from_UV(Y,Mu,W,E,r,U,V,D,g_T,h_T,se_U,se_V)
    var_T_from_B,var_T_from_A = compute_var_T_from_UV(Y,Mu,W,E,r,X,Z,1,g_T,h_T,se_B,se_A)
    
    # Calculate standard errors for S and T
    se_S = sqrt.(1.0./F_S + var_S_from_U + var_S_from_V + var_S_from_A + var_S_from_B)
    se_T = sqrt.(1.0./F_T + var_T_from_U + var_T_from_V + var_T_from_A + var_T_from_B)
    
    if any(isnan.(se_A)); @warn("One or more invalid standard errors in se_A."); end
    if any(isnan.(se_B)); @warn("One or more invalid standard errors in se_B."); end
    if any(isnan.(se_C)); @warn("One or more invalid standard errors in se_C."); end
    if any(isnan.(se_D)); @warn("One or more invalid standard errors in se_D."); end
    if any(isnan.(se_U)); @warn("One or more invalid standard errors in se_U."); end
    if any(isnan.(se_V)); @warn("One or more invalid standard errors in se_V."); end
    if any(isnan.(se_S)); @warn("One or more invalid standard errors in se_S."); end
    if any(isnan.(se_T)); @warn("One or more invalid standard errors in se_T."); end
    
    return se_A,se_B,se_C,se_D,se_U,se_V,se_S,se_T
end



# _________________________________________________________________________________________________
# Functions for estimation in NB-GBM

# Recover A, B, C, D, U, and V, given logMu, X, Z, and M.
function recover_parameters(logMu,X,Z,M; ABC_only=false)
    Q = pinv(X)*logMu
    C = Q*pinv(Z)'
    A = (Q - C*Z')'
    B = logMu*pinv(Z)' - X*C
    if ABC_only; return A,B,C; end
    UDVt = logMu - (X*A' + B*Z' + X*C*Z')
    U,D,V = tsvd(UDVt,M)
    # sgn = vec(sign.(U'*((-1).^(1:size(U,1))))); U = U.*sgn'; V = V.*sgn'  # Apply sign conventions to U,D,V
    return A,B,C,D,U,V
end

# Compute Mu, W, and E
function compute_MuWE!(Mu,W,E,Y,logMu,r)
    Mu .= exp.(logMu)
    W .= (r.*Mu)./(r.+Mu)
    E .= (Y - Mu).*(W./Mu)
end

# Compute X'*diag(w)*X and store it in XtWX
function compute_XtWX!(XtWX,X,w)
    I,K = size(X)
    for k1 = 1:K, k2 = 1:K
        value = 0.0
        for i = 1:I
            value += X[i,k1]*w[i]*X[i,k2]
        end
        XtWX[k1,k2] = value
    end
end

# Compute (X'*(Wj.*X) + diagm(Lambda)) \ (X'*Ej - Lambda.*Aj)
function weighted_least_squares_step(X,Wj,Ej,Aj,Lambda)
    I,K = size(X)
    XtWX = zeros(K,K)
    compute_XtWX!(XtWX,X,Wj)
    for k = 1:K; XtWX[k,k] += Lambda[k]; end
    XE = zeros(K)
    for k = 1:K
        value = 0.0
        for i = 1:I
            value += X[i,k]*Ej[i]
        end
        XE[k] = value - Lambda[k]*Aj[k]
    end
    return XtWX \ XE
end

# Perform optimization-projection step on A (or B)
function update_main_effects(A,C,X,Z,W,E,lambda,max_step,verbose)
    Lambda = lambda*ones(size(X,2))
    max_step_enforced = false
    for j = 1:size(W,2)
        delta = weighted_least_squares_step(X,W[:,j],E[:,j],A[j,:],Lambda)
        A[j,:] = A[j,:] + delta*min(sqrt(size(A,2))*max_step/norm(delta), 1)
        if sqrt(size(A,2))*max_step < norm(delta); max_step_enforced = true; end
    end
    if max_step_enforced && verbose; println("max_step enforced in A[j,:] update for one or more j."); end
    Shift = pinv(Z)*A
    A = A - Z*Shift  # enforce constraint that Z'*A = 0 by projecting onto nullspace of Z'.
    C = C + Shift'  # compensate to preserve likelihood
    return A,C
end

# Perform optimization-projection step on C
function update_interactions(C,X,Z,W,E,lambda_C,max_step)
    L = size(Z,2)
    F_C = hvcat(L, permutedims([X'*((W*(Z[:,l1].*Z[:,l2])).*X) for l1=1:L, l2=1:L])...)
    delta = (F_C + lambda_C*Identity) \ (vec(X'*E*Z) - lambda_C*C[:])
    C[:] = C[:] + delta*min(sqrt(prod(size(C)))*max_step/norm(delta), 1)
    # (no constraints to enforce on C)
    return C
end

# Perform optimization-projection step on UD (or VD)
function update_UD(A,C,U,D,V,X,Z,pinv_X,pinv_Z,W,E,lambda_U,max_step,verbose)
    I = size(X,1)
    J = size(Z,1)
    M = length(D)
    G = U.*D'
    Lambda = lambda_U./(D.^2)
    max_step_enforced = false
    for i = 1:I
        delta = weighted_least_squares_step(V,W[i,:],E[i,:],G[i,:],Lambda)
        G[i,:] = G[i,:] + delta*min(sqrt(M)*max_step/norm(delta), 1)
        if sqrt(M)*max_step < norm(delta); max_step_enforced = true; end
    end
    if max_step_enforced && verbose; println("max_step enforced in G[i,:] update for one or more i."); end
    pinv_X_G = pinv_X*G
    Go = G - X*pinv_X_G
    Ao = A + V*pinv_X_G'
    pinv_Z_Ao = pinv_Z*Ao
    A = Ao - Z*pinv_Z_Ao
    C = C + pinv_Z_Ao'
    U,D,V = tsvd(Go*V',M)
    return A,C,U,D,V
end


# Numerically stable approximations to digamma and trigamma differences
digamma_delta(y,r) = ((r > 10^8) ? log1p(y/r) : digamma(y+r)-digamma(r))
trigamma_delta(y,r) = ((r > 10^8) ? -(y/r)/(y+r) : trigamma(y+r)-trigamma(r))

# Compute derivatives of the log-likelihood with respect to the log-dispersion parameters
function compute_logdispersion_derivatives(Y,Mu,r)
    I,J = size(Y)
    D1 = zeros(I,J)
    D2 = zeros(I,J)
    for i = 1:I, j = 1:J
        D1[i,j] = -r[i,j]*(digamma_delta(Y[i,j],r[i,j]) - log1p(Mu[i,j]/r[i,j]) - (Y[i,j]-Mu[i,j])/(r[i,j]+Mu[i,j]))
        
        if isinf(Mu[i,j]^2)
            D2[i,j] = -D1[i,j] + (r[i,j]^2)*trigamma_delta(Y[i,j],r[i,j]) + r[i,j]
        else
            D2[i,j] = -D1[i,j] + (r[i,j]^2)*trigamma_delta(Y[i,j],r[i,j]) + (Y[i,j] + Mu[i,j]^2/r[i,j]) / (1.0 + Mu[i,j]/r[i,j])^2
        end
    end
    return D1,D2
end

# Perform optimization-projection steps on S and T
function update_logdispersions(S,T,omega,Y,Mu,r,p,max_step,b_S,b_T,update_S,update_T,verbose)
    I,J = size(Y)
    
    if update_S
    D1,D2 = compute_logdispersion_derivatives(Y,Mu,r)
    g = vec(sum(D1; dims=2)) .- p.lambda_S*(S .- p.mu_S)
    h = vec(sum(D2; dims=2)) .- p.lambda_S
    delta = (g./h).*(h.<0) .+ (-g).*(h.>=0)
    S = S - delta.*min.(b_S./abs.(delta), 1)
    if any(abs.(delta) .> b_S) && verbose; println("max step size enforced in S[i] update for one or more i."); end
    b_S = [(abs(delta[i]) > b_S[i] ?  b_S[i]/2 : max_step) for i = 1:I]
    shift = log(mean(exp.(S)))
    S = S .- shift  # Project onto constrained space
    omega = omega + shift  # Compensate to preserve likelihood
    r = exp.(-(S.+T'.+omega))
    end
    
    if update_T    
    D1,D2 = compute_logdispersion_derivatives(Y,Mu,r)
    g = vec(sum(D1; dims=1)) .- p.lambda_T*(T .- p.mu_T)
    h = vec(sum(D2; dims=1)) .- p.lambda_T
    delta = (g./h).*(h.<0) .+ (-g).*(h.>=0)
    T = T - delta.*min.(b_T./abs.(delta), 1)
    if any(abs.(delta) .> b_T) && verbose; println("max step size enforced in T[j] update for one or more j."); end
    b_T = [(abs(delta[j]) > b_T[j] ?  b_T[j]/2 : max_step) for j = 1:J]
    shift = log(mean(exp.(T)))
    T = T .- shift  # Project onto constrained space
    omega = omega + shift  # Compensate to preserve likelihood
    r = exp.(-(S.+T'.+omega))
    end
     
    return S,T,omega,r,b_S,b_T
end


# __________________________________________________________________________________________________
# Functions for inference in NB-GBM

function compute_F_D(U,V,W)
    I,M = size(U)
    J,M = size(V)
    F_D = zeros(M,M)
    for m1 = 1:M, m2 = 1:M
        value = 0.0
        for j = 1:J
            uw = 0.0
            for i = 1:I
                uw += U[i,m1]*U[i,m2]*W[i,j]
            end
            value += uw*V[j,m1]*V[j,m2]
        end
        F_D[m1,m2] = value
    end
    return F_D
end

# Jacobian (transposed) of identifiability constraints on U and V
# (i.e., X'*U=0, Z'*V=0, U'*U=I, and V'*V=I)
function compute_constraint_Jacobian_UV(X,Z,U,V)
    I,M = size(U)
    J,M = size(V)
    
    Q_U_x = kron(X, Diagonal(ones(M)))  # Constraint: vec(U'*X)=0
    Q_V_z = kron(Z, Diagonal(ones(M)))  # Constraint: vec(V'*Z)=0
    
    # Orthogonality contraints on U and V
    Nc = nchoose2(M+1)
    Q_U_u = zeros(I*M,Nc)
    Q_V_v = zeros(J*M,Nc)
    for m = 1:M
        cols = [nchoose2(m).+(1:m) ; nchoose2.(m.+(1:(M-m))).+m]
        Q_U_u[(1:M:I*M).+(m-1), cols] = U
        Q_V_v[(1:M:J*M).+(m-1), cols] = V
        # Note: the factor of 2 for the m'th column can be ignored since the contraints are equivalent.
    end
    
    Q_U = [Q_U_u Q_U_x]
    Q_V = [Q_V_v Q_V_z]
    return Q_U,Q_V
end

function compute_var_C_from_A(X,Z,F_A_inv,F_C_inv,grad_C,dW_dMu_Mu,dE_dMu_Mu)
    I,K = size(X)
    J,L = size(Z)
    dC_dA = zeros(K*L,J*K)  # Jacobian
    dW_da = zeros(I)
    dE_da = zeros(I)
    ZjZjt = zeros(L,L)
    XtWX = zeros(K,K)
    for j = 1:J
        for l1 = 1:L, l2 = 1:L
            ZjZjt[l1,l2] = Z[j,l1]*Z[j,l2]
        end
        for k = 1:K
            for i = 1:I
                dW_da[i] = dW_dMu_Mu[i,j]*X[i,k]
                dE_da[i] = dE_dMu_Mu[i,j]*X[i,k]
            end
            compute_XtWX!(XtWX,X,dW_da)  # Compute XtWX = X'*(dW_da.*X)
            dF_da = kron(ZjZjt, XtWX)
            dC_dA[:,(j-1)*K+k] = F_C_inv*(-dF_da*(F_C_inv*grad_C) + vec((X'*dE_da)*Z[j,:]'))
        end
    end
    F_A_inv_dC_dAt = zeros(J*K,K*L)
    for j = 1:J
        F_A_inv_dC_dAt[block(j,K),:] = F_A_inv[j]*dC_dA[:,((j-1)*K+1):(j*K)]'
    end
    return vec(sum(dC_dA'.*F_A_inv_dC_dAt,dims=1))
end

function compute_var_C_from_B(X,Z,F_B_inv,F_C_inv,grad_C,dW_dMu_Mu,dE_dMu_Mu)
    I,K = size(X)
    J,L = size(Z)
    dC_dB = zeros(K*L,I*L)  # Jacobian
    dW_db = zeros(J)
    dE_db = zeros(J)
    XiXit = zeros(K,K)
    ZtWZ = zeros(L,L)  
    for i = 1:I
        for k1 = 1:K, k2 = 1:K
            XiXit[k1,k2] = X[i,k1]*X[i,k2]
        end
        for l = 1:L
            for j = 1:J
                dW_db[j] = dW_dMu_Mu[i,j]*Z[j,l]
                dE_db[j] = dE_dMu_Mu[i,j]*Z[j,l]
            end
            compute_XtWX!(ZtWZ,Z,dW_db)  # Compute ZtWZ = Z'*(dW_db.*Z)
            dF_db = kron(ZtWZ, XiXit)
            dC_dB[:,(i-1)*L+l] = F_C_inv*(-dF_db*(F_C_inv*grad_C) + vec(X[i,:]*(dE_db'*Z)))
        end
    end
    F_B_inv_dC_dBt = zeros(I*L,K*L)
    for i = 1:I
        F_B_inv_dC_dBt[block(i,L),:] = F_B_inv[i]*dC_dB[:,((i-1)*L+1):(i*L)]'
    end
    return vec(sum(dC_dB'.*F_B_inv_dC_dBt,dims=1))
end

function compute_var_A_from_V(X,U,D,var_V,F_A_inv,grad_A,dW_dMu_Mu,dE_dMu_Mu)
    J,K = size(grad_A)
    I,M = size(U)
    var_A_from_V = zeros(J*K)
    dA_dV = zeros(K,M)
    dW_dv = zeros(I)
    dE_dv = zeros(I)
    XtWX = zeros(K,K)
    for j = 1:J
        for m = 1:M
            for i = 1:I
                dW_dv[i] = dW_dMu_Mu[i,j]*U[i,m]*D[m]
                dE_dv[i] = dE_dMu_Mu[i,j]*U[i,m]*D[m]
            end
            compute_XtWX!(XtWX,X,dW_dv)  # Compute XtWX = X'*(dW_dv.*X)
            dA_dV[:,m] = (-F_A_inv[j]*XtWX)*(F_A_inv[j]*grad_A[j,:]) + F_A_inv[j]*(X'*dE_dv)
        end
        var_A_from_V[block(j,K)] = sum(dA_dV'.*(var_V[block(j,M)].*dA_dV'), dims=1)
    end
    return var_A_from_V
end

function compute_var_A_from_U(X,V,D,var_U,F_A_inv,grad_A,dW_dMu_Mu,dE_dMu_Mu)
    I,K = size(X)
    J,M = size(V)
    dA_dU = zeros(J*K,I*M)  # Jacobian
    for j = 1:J
        Temp = -F_A_inv[j]*(X.*dW_dMu_Mu[:,j])' .* (X*F_A_inv[j]*grad_A[j,:])' + F_A_inv[j]*(X.*dE_dMu_Mu[:,j])'
        for m = 1:M
            dA_dU[block(j,K), (1:M:I*M).+(m-1)] = Temp*V[j,m]*D[m]
        end
    end
    return vec(sum(dA_dU'.*(var_U.*dA_dU'),dims=1))
end

function compute_var_B_from_U(Z,V,D,var_U,F_B_inv,grad_B,dW_dMu_Mu,dE_dMu_Mu)
    return compute_var_A_from_V(Z,V,D,var_U,F_B_inv,grad_B,dW_dMu_Mu',dE_dMu_Mu')
end

function compute_var_B_from_V(Z,U,D,var_V,F_B_inv,grad_B,dW_dMu_Mu,dE_dMu_Mu)
    return compute_var_A_from_U(Z,U,D,var_V,F_B_inv,grad_B,dW_dMu_Mu',dE_dMu_Mu')
end

function compute_var_V_from_A(UD,X,var_A,F_V_inv,grad_V,dW_dMu_Mu,dE_dMu_Mu)
    return compute_var_A_from_V(UD,X,ones(size(X,2)),var_A,F_V_inv,grad_V,dW_dMu_Mu,dE_dMu_Mu)
end

function compute_var_V_from_B(UD,Z,var_B,F_V_inv,grad_V,dW_dMu_Mu,dE_dMu_Mu)
    return compute_var_A_from_U(UD,Z,ones(size(Z,2)),var_B,F_V_inv,grad_V,dW_dMu_Mu,dE_dMu_Mu)
end

function compute_var_U_from_B(VD,Z,var_B,F_U_inv,grad_U,dW_dMu_Mu,dE_dMu_Mu)
    return compute_var_B_from_U(VD,Z,ones(size(Z,2)),var_B,F_U_inv,grad_U,dW_dMu_Mu,dE_dMu_Mu)
end

function compute_var_S_from_UV(Y,Mu,W,E,r,U,V,D,g_S,h_S,se_U,se_V)
    Q = -W.*E./r
    R = -2*W.*E./(r.+Mu)

    # Delta propagation to account for uncertainty in S due to U
    dg_du = Q*(V.*D')
    dh_du = -dg_du + R*(V.*D')
    ds_du = -dg_du./h_S + dh_du.*(g_S./h_S.^2)
    var_S_from_U = vec(sum(ds_du.*(ds_du.*(se_U.^2)); dims=2))
        
    # Delta propagation to account for uncertainty in S due to V
    I = size(U,1)
    var_S_from_V = zeros(I)
    for i = 1:I
        dg_dv = Q[i,:].*(U[i,:].*D)'
        dh_dv = -dg_dv + R[i,:].*(U[i,:].*D)'
        ds_dv = -dg_dv/h_S[i] + dh_dv*(g_S[i]/h_S[i]^2)
        var_S_from_V[i] = sum(ds_dv.*(ds_dv.*(se_V.^2)))
    end
        
    return var_S_from_U,var_S_from_V
end

function compute_var_T_from_UV(Y,Mu,W,E,r,U,V,D,g_T,h_T,se_U,se_V)
     var_T_from_V,var_T_from_U = compute_var_S_from_UV(Y',Mu',W',E',r',V,U,D,g_T,h_T,se_V,se_U)
     return var_T_from_U,var_T_from_V
end


# _________________________________________________________________________________________________
# The following function (compute_constraint_Jacobian) is used only in the full Fisher information matrix version.

# Jacobian (transposed) of identifiability constraints on A, B, U, and V
# (i.e., Z'*A=0, X'*B=0, X'*U=0, Z'*V=0, U'*U=I, and V'*V=I)
function compute_constraint_Jacobian(X,Z,A,B,U,V)
    I,K = size(X)
    J,L = size(Z)
    M = size(U,2)
    
    # Constraints on A and B
    Q_A = kron(Z, Diagonal(ones(K)))
    Q_B = kron(X, Diagonal(ones(L)))
    
    Q_U,Q_V = compute_constraint_Jacobian_UV(X,Z,U,V)
    
    S_A = 1:J*K
    S_B = (1:I*L).+maximum(S_A)
    S_C = (1:K*L).+maximum(S_B)
    S_U = (1:I*M).+maximum(S_C)
    S_V = (1:J*M).+maximum(S_U)
    S_D = (1:M).+maximum(S_V)
    
    Q = zeros(maximum(S_D), K*L+K*L+K*M+Nc+L*M+Nc)
    Q[S_A,1:K*L] = Q_A
    Q[S_B,(1:K*L).+K*L] = Q_B
    Q[S_U,(1:(K*M+Nc)).+K*L.+K*L] = Q_U
    Q[S_V,(1:(L*M+Nc)).+K*L.+K*L.+K*M.+Nc] = Q_V
    
    return Q,Q_A,Q_B,Q_U,Q_V
end

























