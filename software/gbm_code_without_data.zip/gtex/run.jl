# Analyze RNA-seq data from GTEx

# _________________________________________________________________________________________________
# Load functions

using RData
using CSV
using DataFrames
using CategoricalArrays
using DelimitedFiles
using Random
using Dates
include("../splines.jl")
include("../helper.jl")
include("../gbm.jl")

rc("font", family="Georgia")


# _________________________________________________________________________________________________
# Load data

Random.seed!(0)

Y0 = load("data.rda")["counts"]
gene_info = CSV.read("gene_info.txt"; delim='\t')
sample_info = CSV.read("sample_info.txt"; delim='\t')
I0,J0 = size(Y0)

# Choose a subset of samples to use
samples_to_use = findall(sample_info[!,:passed_qc].==1)

# Choose a subset of genes to use
genes_to_use = 1:I0

# Reduce to subset
Y = Y0[genes_to_use, samples_to_use]
sample_info = sample_info[samples_to_use,:]
gene_info = gene_info[genes_to_use,:]
I,J = size(Y)


# _________________________________________________________________________________________________
# Model definition

# Construct gene-specific design matrix
println("Constructing gene-specific design matrix...")
X_loglength = log.(gene_info[!,:seq_len])
X_gc = [gene_info[!,:pct_gc]  moment2(gene_info[!,:pct_gc])]
X = [ones(I) X_loglength X_gc]
X[:,2:end] = scale(X[:,2:end],1)

# Construct sample-specific design matrix
println("Constructing sample-specific design matrix...")
Z,Znames = design_matrix(@formula(sampid ~ 1), sample_info)



# _________________________________________________________________________________________________
# Compute latent factors for visualization

M = 2  # number of latent factors to use
max_iterations = 20
results_dir = "results-viz-M=$M"

println("Estimating parameters...")
@time A,B,C,D,U,V,S,T,omega,logp_r = gbm_estimation(Y,X,Z,M; max_iterations=max_iterations, verbose=true)

colors = ["#e6194b", "#3cb44b", "#0000b3", "#f58231", "#911eb4", "#46f0f0", "#f032e6", "#d2f53c", "#fabebe", "#008080", "#e6beff", "#aa6e28", "#fffac8", "#800000", "#aaffc3", "#808000", "#ffd8b1", "#0082c8", "#808080", "#edc61a", "#FFFFFF", "#000000", "#008040", "#6cb5d9", "#ace639", "#ccf5ff", "#aa79f2", "#FFFF00", "#c7d9a3", "#73341d"]

colorbycategory = [:smts,:smtsd]
if !isdir(results_dir); mkdir(results_dir); end
for (colorby,descriptor) in [(:smts,"tissue"),(:smtsd,"subtissue")]
    for m = 1:2:(M-1)
        println("_________ $colorby (dims $m and $(m+1)) _________")
        figure(1, figsize=(10,7)); clf(); grid(linewidth=0.25)
        subplots_adjust(left=0.08, bottom=0.08, top=0.95, right=0.95)
        cvalue = sample_info[!,colorby]
        if colorby in colorbycategory
            plotgroups(V[:,m], V[:,m+1], string.(cvalue); ms=2, mec="k", mew=0.1)
            if length(unique(cvalue)) > 35
                subplots_adjust(right=0.8)
                legend(fontsize=6, loc=2, bbox_to_anchor=[1.005,1], borderaxespad=0.0, markerscale=2)
            elseif length(unique(cvalue)) > 10
                subplots_adjust(right=0.85)
                legend(fontsize=8, loc=2, bbox_to_anchor=[1.005,1], borderaxespad=0.0, markerscale=3)
            else
                legend(fontsize=8, markerscale=3)
            end
        else
            mis = ismissing.(cvalue)
            scatter(V[.!mis,m], V[.!mis,m+1], 8, c=cvalue[.!mis]; edgecolor="k", linewidth=0.1)
            colorbar(fraction=0.04)
            plot(V[mis,m], V[mis,m+1], "kx", ms=2.5, mew=0.35)
        end
        xlabel("latent factor $m")
        ylabel("latent factor $(m+1)")
        title("GBM latent factorization (coloring by $descriptor)")
        savefig("$results_dir/$colorby-$m$(m+1).png",dpi=250)
    end
end


# Compare with doing PCA on TPMs
RPM, RPKM, TPM = standard_normalizations(Y, gene_info[!,:seq_len])
figure(1, figsize=(10,7)); clf(); grid(linewidth=0.25)
subplots_adjust(left=0.08, bottom=0.08, top=0.95, right=0.85)
group = string.(sample_info[!,:smts])
pc = pcaplot(log.(TPM.+1), group; ms=2, mec="k", mew=0.1)
legend(fontsize=8, loc=2, bbox_to_anchor=[1.005,1], borderaxespad=0.0, markerscale=3)
title("PCA of TPMs for GTEx data (coloring by tissue)")
savefig("$results_dir/pca-TPMs-smts.png",dpi=250)


# Compare with DESeq2's PCA approach using VST
figure(1, figsize=(10,7)); clf(); grid(linewidth=0.25)
subplots_adjust(left=0.08, bottom=0.08, top=0.95, right=0.85)
# group = string.(sample_info[!,:smts])
pc_deseq = CSV.read("$results_dir/deseq2-pca-gc=TRUE.txt"; delim='\t')
plotgroups(pc_deseq[!,:PC1],pc_deseq[!,:PC2],pc_deseq[!,:group]; ms=2, mec="k", mew=0.1)
legend(fontsize=8, loc=2, bbox_to_anchor=[1.005,1], borderaxespad=0.0, markerscale=3)
xlabel("PC1")
ylabel("PC2")
title("PCA of DESeq2 transformation of GTEx data (coloring by tissue)")
savefig("$results_dir/pca-deseq2-smts-gc=true.png",dpi=200)


















