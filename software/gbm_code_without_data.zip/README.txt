Source code for the examples in "Inference in generalized bilinear models".


Contents:
	gbm.jl - main functions for GBM estimation and inference
	helper.jl - various helper functions
	sim.jl - code for running simulations
	splines.jl - functions for spline basis construction
	ccle - code for the application to cancer genomics using the CCLE data
	gtex - code for the application to gene expression analysis using the GTEx data
	pickrell - code for the application to gene expression analysis using the Pickrell data
	

The source code is written in the Julia language (https://julialang.org/).  The code was implemented using Julia v1.3.1, so if you use a different version of Julia then tweaks might be needed.  The required Julia packages can be installed at the Julia command line by running, for instance,
    Pkg.add("Distributions")

The PyPlot package can be installed by running:
    ENV["PYTHON"]=""
    if (Pkg.installed("PyCall")!=nothing); Pkg.build("PyCall"); end
    Pkg.add("PyPlot")
    using PyPlot

To execute a given Julia file, say sim.jl, cd to the appropriate folder, e.g., cd("../folder"), and do:
    include("sim.jl")







